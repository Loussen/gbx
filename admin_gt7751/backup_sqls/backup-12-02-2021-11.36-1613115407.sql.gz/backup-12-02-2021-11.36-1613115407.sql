-- ---------------------------------------------------------
--
-- SIMPLE SQL Dump
--
-- nawa (at) yahoo (dot) com
--
-- Host Connection Info: localhost via TCP/IP
-- Generation Time: February 12, 2021 at 11:36 AM ( Asia/Baku )
-- Server version: 100413
-- PHP Version: 7.4.8
--
-- ---------------------------------------------------------



SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;


-- ---------------------------------------------------------
--
-- Table structure for table : `about`
--
-- ---------------------------------------------------------

CREATE TABLE `about` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_en` varchar(255) NOT NULL,
  `name_ru` varchar(255) NOT NULL,
  `name_az` varchar(255) NOT NULL,
  `short_text_en` text NOT NULL,
  `short_text_ru` text NOT NULL,
  `short_text_az` text NOT NULL,
  `full_text_en` text NOT NULL,
  `full_text_ru` text NOT NULL,
  `full_text_az` text NOT NULL,
  `image` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `about`
--

INSERT INTO `about` (`id`, `name_en`, `name_ru`, `name_az`, `short_text_en`, `short_text_ru`, `short_text_az`, `full_text_en`, `full_text_ru`, `full_text_az`, `image`) VALUES
(1, '', '', 'FİZİOTERAPEVT Dr. Ramazan Nəsirli', '', '', 'Fizioterapevt Dr. Ramazan Nasırlı 2017-ci ildə Türkiyənin Ankara şəhərində yerləşən Hacettepe Universitetində Fiziki müalicə və Reabilitasiya üzrə təhsil almış və bir müddət İzmirin “Yeşilyurd Fiziksel Tibb reabilitasiyon Merkezi”-də çalışmışdır.\n\n2019-cu ildən etibarən Milli İdman Tibb və Reabilitasya İnstitutunda çalışmışdır. Hazırda "Medera" hospitalda işləyir.\n\n\n\nFizioterapvt Dr. Ramazan Nasırlı \n\n• Dry Needing (quru iynəbatırma) kursu\n\n• Mulligan Manual terapiya\n\n• Cupping terapi\n\n• Udma bozukluklarinda reabilitasiya\n\n• Kinezyoteyp\n\n• Akupunktur\n\n• Graston kimi bir çox kurslarda iştirak edib\n\n\n\nHansı xəstəliklərdən əziyyət çəkənlər müraciət edə bilərlər?', '', '', '<p>Fizioterapevt Dr. Ramazan Nasırlı 2017-ci ildə Türkiyənin Ankara şəhərində yerləşən Hacettepe Universitetində Fiziki müalicə və Reabilitasiya üzrə təhsil almış və bir müddət İzmirin &ldquo;Yeşilyurd Fiziksel Tibb reabilitasiyon Merkezi&rdquo;-də çalışmışdır.<br />2019-cu ildən etibarən Milli İdman Tibb və Reabilitasya İnstitutunda çalışmışdır. Hazırda "Medera" hospitalda işləyir.</p>\n<p>Fizioterapvt Dr. Ramazan Nasırlı <br />&bull; Dry Needing (quru iynəbatırma) kursu<br />&bull; Mulligan Manual terapiya<br />&bull; Cupping terapi<br />&bull; Udma bozukluklarinda reabilitasiya<br />&bull; Kinezyoteyp<br />&bull; Akupunktur<br />&bull; Graston kimi bir çox kurslarda iştirak edib</p>\n<p>Hansı xəstəliklərdən əziyyət çəkənlər müraciət edə bilərlər?</p>\n<p>&bull; Osteoxondroz<br />&bull; Boyun qrijaları<br />&bull; Pleksit<br />&bull; Miqren ağrıları<br />&bull; Kifoz, lordoz, skolioz<br />&bull; Onurğanın yaralanma sonrası müalicəsi<br />&bull; Kuadriplejik və paraplejik xəstələrin müalicəsi<br />&bull; Bel ağrıları<br />&bull; Diz ağrıları<br />&bull; Ayaq ağrıları<br />&bull; İnsult<br />&bull; DCP<br />&bull; Düşən muskullar distrofiki<br />&bull; Parkinson<br />&bull; Multiple Skleroz<br />&bull; Amyotrofik lateral skleroz<br />&bull; Udma çətinliyi (disfagiya)<br />&bull; Karpal tünel sindromu<br />&bull; Kubital tünel sindromu</p>\n<p>Müalicədə istifadə etdiyi üsullar:<br />&bull; Graston teknik (miyosaial gevşetme )<br />&bull; Dry needlingle elektrik stimulasyonu<br />&bull; Cupping massaj<br />&bull; Mulligan Manual terapiya<br />&bull; Müalicəvi idman<br />&bull; Bütün növ elektroterapiya üsulları<br />&bull; Nevrolojik xəstələrin Reabilitasyasi<br />&bull; Ortopedik Və Nevrolojik Əməliyatlardan sonraki Reabilitasya<br />&bull; Kineshio tape<br />&bull; Acupuncture<br />&bull; Hissiyat pozğunluğunun bərpası<br />&bull; Udma pozğunluğunun bərpası<br />&bull; Tənəffus pozgunlugunun bərpası<br />&bull; Dry Needeng (quru iynəbatirma) terapiyası<br />&bull; Müalicəvi masaj<br />&bull; Friksiyon Masaji<br />&bull; Reanimasia xestelerinin ilkin Reabilitasyasi<br />&bull; Protez-ortez xəstələrinin reabilitasyasi<br />&bull; Skalyoz və Kifoz reabilitasyasi<br />&bull; Əl Cərrahiyəsi sonrasi Reabilitasya<br />&bull; Travmatik əməlyatlar sonrası reabilitasya<br />&bull; Uşaq serebral ifliclərinin reabilitasyasi<br />&bull; İdman travmalari sonrasi Reabilitasya<br />&bull; Çiyin əməliyyatlarindan sonraki Reabilitasya<br />&bull; Diz əməliyyatlarindan sonraki Reabilitasya</p>', 'fizioterapevtramazannesirli-1610787332.jpg');



-- ---------------------------------------------------------
--
-- Table structure for table : `admin_roles`
--
-- ---------------------------------------------------------

CREATE TABLE `admin_roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `permissions` text NOT NULL,
  `position` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL,
  `important` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin_roles`
--

INSERT INTO `admin_roles` (`id`, `name`, `permissions`, `position`, `active`, `important`) VALUES
(1, 'Baş admin', '{"index":{"see":1,"add":0,"edit":0,"delete":0,"position":0,"active":0},"admins":{"see":1,"add":1,"edit":1,"delete":1,"position":0,"active":0},"settings_inner":{"see":1,"add":1,"edit":1,"delete":1,"position":0,"active":0},"logout":{"see":1,"add":0,"edit":0,"delete":0,"position":0,"active":0},"home_page":{"see":1,"add":0,"edit":1,"delete":0,"position":0,"active":0},"streets":{"see":1,"add":1,"edit":1,"delete":1,"position":1,"active":1},"buildings":{"see":1,"add":1,"edit":1,"delete":1,"position":1,"active":1},"managers":{"see":1,"add":1,"edit":1,"delete":1,"position":1,"active":1},"contractors":{"see":1,"add":1,"edit":1,"delete":1,"position":1,"active":1},"banks":{"see":1,"add":1,"edit":1,"delete":1,"position":1,"active":1},"repair_types":{"see":1,"add":1,"edit":1,"delete":1,"position":1,"active":1},"licenses":{"see":1,"add":1,"edit":1,"delete":1,"position":1,"active":1},"sale_types":{"see":1,"add":1,"edit":1,"delete":1,"position":1,"active":1},"sales":{"see":1,"add":1,"edit":1,"delete":1,"position":0,"active":0},"list":{"see":1,"add":0,"edit":0,"delete":0,"position":0,"active":0},"payments":{"see":1,"add":1,"edit":0,"delete":1,"position":0,"active":0},"penals":{"see":1,"add":0,"edit":1,"delete":0,"position":0,"active":0},"cash_desks":{"see":1,"add":1,"edit":1,"delete":1,"position":1,"active":1},"admin_roles":{"see":1,"add":1,"edit":1,"delete":1,"position":1,"active":1}}', 1, 1, 1);



-- ---------------------------------------------------------
--
-- Table structure for table : `admins`
--
-- ---------------------------------------------------------

CREATE TABLE `admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(50) NOT NULL,
  `pass` varchar(50) NOT NULL,
  `salt` varchar(50) NOT NULL,
  `important` tinyint(1) NOT NULL,
  `role_id` int(11) NOT NULL,
  `permissions` text NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `login`, `pass`, `salt`, `important`, `role_id`, `permissions`, `active`) VALUES
(1, 'admin', '301e3cff87ca3e8df44beeb52c395d7e', '+YFciS_)zy%KROuy=Yzu', 0, 1, '{"index":{"see":1,"add":0,"edit":0,"delete":0,"position":0,"active":0},"admins":{"see":1,"add":1,"edit":1,"delete":1,"position":0,"active":0},"settings_inner":{"see":1,"add":1,"edit":1,"delete":1,"position":0,"active":0},"logout":{"see":1,"add":0,"edit":0,"delete":0,"position":0,"active":0},"home_page":{"see":1,"add":0,"edit":1,"delete":0,"position":0,"active":0},"streets":{"see":1,"add":1,"edit":1,"delete":1,"position":1,"active":1},"buildings":{"see":1,"add":1,"edit":1,"delete":1,"position":1,"active":1},"managers":{"see":1,"add":1,"edit":1,"delete":1,"position":1,"active":1},"contractors":{"see":1,"add":1,"edit":1,"delete":1,"position":1,"active":1},"banks":{"see":1,"add":1,"edit":1,"delete":1,"position":1,"active":1},"repair_types":{"see":1,"add":1,"edit":1,"delete":1,"position":1,"active":1},"licenses":{"see":1,"add":1,"edit":1,"delete":1,"position":1,"active":1},"sale_types":{"see":1,"add":1,"edit":1,"delete":1,"position":1,"active":1},"sales":{"see":1,"add":1,"edit":1,"delete":1,"position":0,"active":0},"list":{"see":1,"add":0,"edit":0,"delete":0,"position":0,"active":0},"payments":{"see":1,"add":1,"edit":0,"delete":1,"position":0,"active":0},"penals":{"see":1,"add":0,"edit":1,"delete":0,"position":0,"active":0},"cash_desks":{"see":1,"add":1,"edit":1,"delete":1,"position":1,"active":1},"admin_roles":{"see":1,"add":1,"edit":1,"delete":1,"position":1,"active":1}}', 1);



-- ---------------------------------------------------------
--
-- Table structure for table : `appointment`
--
-- ---------------------------------------------------------

CREATE TABLE `appointment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_en` varchar(255) NOT NULL,
  `name_ru` varchar(255) NOT NULL,
  `name_az` varchar(255) NOT NULL,
  `full_text_en` text NOT NULL,
  `full_text_ru` text NOT NULL,
  `full_text_az` text NOT NULL,
  `image` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`id`, `name_en`, `name_ru`, `name_az`, `full_text_en`, `full_text_ru`, `full_text_az`, `image`) VALUES
(1, '', 'Müayinəyə yazılın1', 'Müayinəyə yazıl', '', '', '<h2>Müayinəyə yazılmaq üçün zəhmət olmasa aşağıdakı formu doldurun.</h2>', 'fiziki-reabilitasiya-hekimi-1608230722.png');



-- ---------------------------------------------------------
--
-- Table structure for table : `appointment_users`
--
-- ---------------------------------------------------------

CREATE TABLE `appointment_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `surname` varchar(50) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `message` text NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp(),
  `seen_by_admin` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `appointment_users`
--

INSERT INTO `appointment_users` (`id`, `name`, `surname`, `phone`, `message`, `datetime`, `seen_by_admin`) VALUES
(2, 'Ayshan', 'Mammadli', 513213199, '', '2021-01-02 04:41:03', 0),
(3, 'Ilhamiyye', 'Tagiyeva', 0505249013, 'Bel omba ve ayag agrilari', '2021-01-13 09:13:09', 1);



-- ---------------------------------------------------------
--
-- Table structure for table : `authors`
--
-- ---------------------------------------------------------

CREATE TABLE `authors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_en` varchar(50) DEFAULT NULL,
  `name_ru` varchar(50) DEFAULT NULL,
  `name_az` varchar(255) NOT NULL,
  `text_en` text NOT NULL,
  `text_ru` text NOT NULL,
  `text_az` text NOT NULL,
  `image` varchar(100) NOT NULL,
  `last_post_time` int(11) NOT NULL,
  `active` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `authors`
--

INSERT INTO `authors` (`id`, `name_en`, `name_ru`, `name_az`, `text_en`, `text_ru`, `text_az`, `image`, `last_post_time`, `active`) VALUES
(8, '', '', '', '', '', '', '4914038-image-1511074689.jpg', 0, 1);



-- ---------------------------------------------------------
--
-- Table structure for table : `banks`
--
-- ---------------------------------------------------------

CREATE TABLE `banks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `percent` int(11) NOT NULL,
  `period` tinyint(1) NOT NULL COMMENT '0=>yearly,1=>montly,2=>daily',
  `position` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



-- ---------------------------------------------------------
--
-- Table structure for table : `banners`
--
-- ---------------------------------------------------------

CREATE TABLE `banners` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_en` varchar(255) NOT NULL,
  `name_ru` varchar(255) NOT NULL,
  `name_az` varchar(255) NOT NULL,
  `text_en` text NOT NULL,
  `text_ru` text NOT NULL,
  `text_az` text NOT NULL,
  `position` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `banners`
--

INSERT INTO `banners` (`id`, `name_en`, `name_ru`, `name_az`, `text_en`, `text_ru`, `text_az`, `position`, `active`) VALUES
(1, '', '', '', '', '', '', 1, 1);



-- ---------------------------------------------------------
--
-- Table structure for table : `cash_desks`
--
-- ---------------------------------------------------------

CREATE TABLE `cash_desks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `program_id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `payment_type` tinyint(1) NOT NULL COMMENT '0=>income,1=>out,2=>both',
  `important` tinyint(1) NOT NULL,
  `position` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



-- ---------------------------------------------------------
--
-- Table structure for table : `categories`
--
-- ---------------------------------------------------------

CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_en` varchar(255) NOT NULL,
  `name_ru` varchar(255) NOT NULL,
  `name_az` varchar(255) NOT NULL,
  `text_en` text NOT NULL,
  `text_ru` text NOT NULL,
  `text_az` text NOT NULL,
  `position` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name_en`, `name_ru`, `name_az`, `text_en`, `text_ru`, `text_az`, `position`, `active`) VALUES
(3, 'Musculoskeletal System', 'Мышечная Система', '', '', '', '', 1, 1),
(4, 'Digestive System', 'Пищеварительная Система', '', '', '', '', 2, 1),
(5, 'Vitamin-Mineral Supplements', 'Витаминно-минеральные добавки', '', '', '', '', 3, 1),
(6, 'Respiratory System', 'Дыхательная Cистема', '', '', '', '', 4, 1),
(7, 'Immune System', 'Иммунная Cистема', '', '', '', '', 5, 1),
(8, 'Antioxidants', 'Антиоксиданты', '', '', '', '', 6, 1),
(9, 'Nervous System', 'Нервная Система', '', '', '', '', 7, 1),
(10, 'For Kids', 'Для Детей', '', '', '', '', 8, 1),
(11, 'Cosmetics & Dermocosmetics', 'Косметика и Дермокосметика', '', '', '', '', 9, 1),
(12, '', '', '', '', '', '', 10, 0),
(13, 'Eye Health', 'Здоровье Глаз', '', '', '', '', 11, 1),
(14, 'Sexual Health', 'Сексуальное Здоровье', '', '', '', '', 12, 1),
(15, 'Disinfectant & Antiseptic Products', 'Дезинфицирующие и Антисептические Средства', '', '', '', '', 13, 1),
(16, 'Medical Products', 'Изделия Медицинского Назначения', '', '', '', '', 14, 1),
(17, 'Special Products', 'Специальные Продукты', '', '', '', '', 15, 1),
(19, 'Urological products', 'Урологические продукты', '', '', '', '', 16, 1);



-- ---------------------------------------------------------
--
-- Table structure for table : `categories2`
--
-- ---------------------------------------------------------

CREATE TABLE `categories2` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_en` varchar(255) NOT NULL,
  `name_ru` varchar(255) NOT NULL,
  `name_az` varchar(255) NOT NULL,
  `text_en` text NOT NULL,
  `text_ru` text NOT NULL,
  `text_az` text NOT NULL,
  `position` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;



-- ---------------------------------------------------------
--
-- Table structure for table : `comments`
--
-- ---------------------------------------------------------

CREATE TABLE `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `information_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `comment` text NOT NULL,
  `active` tinyint(1) NOT NULL,
  `datetime` int(11) NOT NULL,
  `table_name` varchar(255) NOT NULL,
  `seen_by_admin` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `information_id`, `name`, `comment`, `active`, `datetime`, `table_name`, `seen_by_admin`) VALUES
(2, 0, 'er', 'test', 1, 0, 'qweqwr', 0);



-- ---------------------------------------------------------
--
-- Table structure for table : `company_info`
--
-- ---------------------------------------------------------

CREATE TABLE `company_info` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `currency_id` tinyint(2) NOT NULL,
  `image_logo` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Proqramin satisi';



-- ---------------------------------------------------------
--
-- Table structure for table : `contacts`
--
-- ---------------------------------------------------------

CREATE TABLE `contacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text_en` text NOT NULL,
  `text_ru` text NOT NULL,
  `text_az` text NOT NULL,
  `footer_en` text NOT NULL,
  `footer_ru` text NOT NULL,
  `footer_az` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `facebook` varchar(255) NOT NULL,
  `twitter` varchar(255) NOT NULL,
  `vkontakte` varchar(255) NOT NULL,
  `linkedin` varchar(255) NOT NULL,
  `digg` varchar(255) NOT NULL,
  `flickr` varchar(255) NOT NULL,
  `dribbble` varchar(255) NOT NULL,
  `vimeo` varchar(255) NOT NULL,
  `myspace` varchar(255) NOT NULL,
  `google` varchar(255) NOT NULL,
  `youtube` varchar(255) NOT NULL,
  `instagram` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `skype` varchar(255) NOT NULL,
  `fax` varchar(255) NOT NULL,
  `google_map` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `text_en`, `text_ru`, `text_az`, `footer_en`, `footer_ru`, `footer_az`, `email`, `facebook`, `twitter`, `vkontakte`, `linkedin`, `digg`, `flickr`, `dribbble`, `vimeo`, `myspace`, `google`, `youtube`, `instagram`, `phone`, `mobile`, `skype`, `fax`, `google_map`) VALUES
(1, '', 'Баку Медикал Плаза\n\nAZ1142, Проспект Бабека 92Н Хатаинский р-н', 'Medera hospital\n\n8 mkr, Ə.Naxçıvani küç, 18', '', '', '', 'info@ramazannasirli.az', 'https://www.facebook.com/FizioterapevtDrRamazanNasirli/', '', 'http://www.vkontakte.ru', '', 'http://www.digg.com', 'http://www.flickr.com', '', '', 'http://www.myspace.com', '', 'https://www.youtube.com/channel/UCpBAwK6LzNd-KXGQGtVau0A', 'https://www.instagram.com/dr.ramazannesirli/', '(+99412) 123456', '+994 (055) 690 18 04', 'skype', 123456, '(40.37801404257197, 49.945913320539944)');



-- ---------------------------------------------------------
--
-- Table structure for table : `currency`
--
-- ---------------------------------------------------------

CREATE TABLE `currency` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usd` varchar(255) NOT NULL,
  `eur` varchar(255) NOT NULL,
  `rub` varchar(255) NOT NULL,
  `gel` varchar(255) NOT NULL,
  `gbp` varchar(255) NOT NULL,
  `sar` varchar(255) NOT NULL,
  `try` varchar(255) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `currency`
--

INSERT INTO `currency` (`id`, `usd`, `eur`, `rub`, `gel`, `gbp`, `sar`, `try`, `date`) VALUES
(1, 1.7001, 2.0346, 0.0298, 0, 0, 0, 0, '2018-01-09');



-- ---------------------------------------------------------
--
-- Table structure for table : `description`
--
-- ---------------------------------------------------------

CREATE TABLE `description` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title_en` varchar(255) NOT NULL,
  `title_ru` varchar(255) NOT NULL,
  `title_az` varchar(255) NOT NULL,
  `description_en` text NOT NULL,
  `description_ru` text NOT NULL,
  `description_az` varchar(255) NOT NULL,
  `keywords_en` text NOT NULL,
  `keywords_ru` text NOT NULL,
  `keywords_az` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `description`
--

INSERT INTO `description` (`id`, `title_en`, `title_ru`, `title_az`, `description_en`, `description_ru`, `description_az`, `keywords_en`, `keywords_ru`, `keywords_az`) VALUES
(1, 'Vusal Eyvazov', 'Альголог Вусал Эйвазов', 'FİZİOTERAPEVT Dr. Ramazan Nəsirli', 'Vusal Eyvazov', 'Альголог Вусал Эйвазов, врач который лечит боль', 'Skalioz, kifoz, osteoxondroz, əməliyyat sonrası reabilitasiya, Serebral iflic, FİZİOTERAPEVT Dr. Ramazan Nasirli', 'Vusal Eyvazov', 'Альголог, Вусал Эйвазов', 'FİZİOTERAPEVT, Ramazan Nasirli, Skaliozun müalicəsi, kifozun müalicəsi, lordozun müalicəsi, osteoxondrozun mualicesi, baş ağrıları, bel ağrıları, boyun ağrıları'),
(3, 'Vusal Eyvazov', 'Альголог Вусал Эйвазов', 'FİZİOTERAPEVT Dr. Ramazan Nəsirli', 'Vusal Eyvazov', 'Альголог Вусал Эйвазов, врач который лечит боль', 'Skalioz, kifoz, osteoxondroz, əməliyyat sonrası reabilitasiya, Serebral iflic, FİZİOTERAPEVT Dr. Ramazan Nasirli', 'Vusal Eyvazov', 'Альголог, Вусал Эйвазов', 'FİZİOTERAPEVT, Ramazan Nasirli, Skaliozun müalicəsi, kifozun müalicəsi, lordozun müalicəsi, osteoxondrozun mualicesi, baş ağrıları, bel ağrıları, boyun ağrıları'),
(2, 'Vusal Eyvazov', 'Альголог Вусал Эйвазов', 'FİZİOTERAPEVT Dr. Ramazan Nəsirli', 'Vusal Eyvazov', 'Альголог Вусал Эйвазов, врач который лечит боль', 'Skalioz, kifoz, osteoxondroz, əməliyyat sonrası reabilitasiya, Serebral iflic, FİZİOTERAPEVT Dr. Ramazan Nasirli', 'Vusal Eyvazov', 'Альголог, Вусал Эйвазов', 'FİZİOTERAPEVT, Ramazan Nasirli, Skaliozun müalicəsi, kifozun müalicəsi, lordozun müalicəsi, osteoxondrozun mualicesi, baş ağrıları, bel ağrıları, boyun ağrıları');



-- ---------------------------------------------------------
--
-- Table structure for table : `documents`
--
-- ---------------------------------------------------------

CREATE TABLE `documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_en` varchar(50) NOT NULL,
  `name_ru` varchar(50) NOT NULL,
  `name_az` varchar(255) NOT NULL,
  `text_en` text NOT NULL,
  `text_ru` text NOT NULL,
  `text_az` text NOT NULL,
  `document` varchar(255) NOT NULL,
  `datetime` int(11) NOT NULL,
  `position` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;



-- ---------------------------------------------------------
--
-- Table structure for table : `employees`
--
-- ---------------------------------------------------------

CREATE TABLE `employees` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name_en` varchar(100) NOT NULL,
  `name_ru` varchar(100) NOT NULL,
  `name_az` varchar(255) NOT NULL,
  `profession_en` varchar(255) NOT NULL,
  `profession_ru` varchar(255) NOT NULL,
  `profession_az` varchar(255) NOT NULL,
  `full_text_en` text NOT NULL,
  `full_text_ru` text NOT NULL,
  `full_text_az` text NOT NULL,
  `image` varchar(100) NOT NULL,
  `link` varchar(255) NOT NULL,
  `position` int(11) NOT NULL,
  `active` int(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id`, `category_id`, `name_en`, `name_ru`, `name_az`, `profession_en`, `profession_ru`, `profession_az`, `full_text_en`, `full_text_ru`, `full_text_az`, `image`, `link`, `position`, `active`) VALUES
(25, 0, '', '', '', '', '', '', '', '', '', 'client-1-1561109234.jpg', '', 0, 1),
(26, 0, '', '', '', '', '', '', '', '', '', 'client-1-1561109251.jpg', '', 0, 1);



-- ---------------------------------------------------------
--
-- Table structure for table : `faq`
--
-- ---------------------------------------------------------

CREATE TABLE `faq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question_en` varchar(255) NOT NULL,
  `question_ru` varchar(255) NOT NULL,
  `question_az` varchar(255) NOT NULL,
  `answer_en` text NOT NULL,
  `answer_ru` text NOT NULL,
  `answer_az` text NOT NULL,
  `position` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `faq`
--

INSERT INTO `faq` (`id`, `question_en`, `question_ru`, `question_az`, `answer_en`, `answer_ru`, `answer_az`, `position`, `active`) VALUES
(1, '', 'Какие рискованные действия могут создать условия для образования грыжи в поясничном отделе спины?', 'Passiv əzələ stimulyasiyası necə həyata keçirilir?', '', 'Поднятие предметов с пола, не сгибая ноги в коленях, толкание и подъём тяжелых предметов, не сгибая ноги в коленях, поднятие груза на плечи и вытягивание вверх, а также перенос тяжелых грузов на большие расстояния может вызвать грыжу поясничного отдела спины.', 'Bədənin müxtəlif nayihələrində yumuşaq toxuma problemləri, oynaq problemləri və əzələ-sümük problemlərinin müalicəsində istifadə edilən passiv əzələ stimulyasiyası xüsusi cihazlarla həyata keçirilən passivreabilitasiya metodudur.', 1, 1),
(2, '', 'Есть ли возрастные ограничения для озонотерапии?', 'Aşağı ətrafların reabilitasiyası necə həyata keçirilir?', '', 'Для озонотерапии нет возрастных ограничений.', 'Aşağı ətrafların reabilitasiyasında mexanoterapiya, müalicəvi idman terapiyası, aktiv və passsiv terapiya, hidroterapiya, termoterapiya, elektroterapiya, maqnit terapiyası və lazer terapiyasından və yaxud bunların kombinasiyasından istifadə olunur.', 2, 1),
(3, '', 'Лечите ли вы остаточные боли у спортсменов?', 'Bel ağrılarını aradan qaldırmaq üçün hansı prosedurları həyata keçirirsiniz?', '', 'Да, спортсмены, которые страдают от возникших и длительных болей, также проходят лечение. До сих пор многие спортсмены обращались к нам с различными остаточными болями. Все, кто прошёл лечение, остались довольны результатами.', 'Bel ağrılarını aradan qaldırmaq üçün həyata keçirilən isti, soyuq applikasiyalar, ultrasəs və elektrik stimulyasiya və eləcə də bəzi əzələ boşaldıcı metodlar bel əzələlərində və yumşaq toxumalarında ağrının azalmasına kömək edə bilər', 4, 1),
(4, '', 'Будет ли применяться общая анестезия во время хирургической операции при боли в спине?', 'Əllərin hərəkətliliyini artırmaq üçün nələr etmək olar ?', '', 'Во время болей в спине общая анестезия не применяется. Операция проводится под местной анестезией. Через один или два часа после операции пациента выписывают домой. После операции пациент может спокойно идти домой.', 'Əllərin hərəkətliliyini artırmaq üçün əl reabilitasiyası həyata keçirilir. Yaralanan və ya zədələnən, karpal tunel sindromu kimi, barmaqlarda yaranan tətik barmaq (triger finger),  swaneck (qu boynu) deformasiyası, butonier (düymə iliyi) kimi eybəcərlikləri aradan qaldırmaq üçün xüsusi əl terapiyası tətbiq edilir.', 3, 1);



-- ---------------------------------------------------------
--
-- Table structure for table : `faq_categories`
--
-- ---------------------------------------------------------

CREATE TABLE `faq_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_en` varchar(255) NOT NULL,
  `name_ru` varchar(255) NOT NULL,
  `name_az` varchar(255) NOT NULL,
  `text_en` text NOT NULL,
  `text_ru` text NOT NULL,
  `text_az` text NOT NULL,
  `position` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `faq_categories`
--

INSERT INTO `faq_categories` (`id`, `name_en`, `name_ru`, `name_az`, `text_en`, `text_ru`, `text_az`, `position`, `active`) VALUES
(7, '', '', '', '', '', '', 2, 1),
(9, '', '', '', '', '', '', 1, 1),
(10, '', '', '', '', '', '', 3, 1);



-- ---------------------------------------------------------
--
-- Table structure for table : `fb_admins`
--
-- ---------------------------------------------------------

CREATE TABLE `fb_admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fb_id` bigint(20) NOT NULL,
  `aktivlik` int(11) NOT NULL,
  PRIMARY KEY (`id`,`fb_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `fb_admins`
--

INSERT INTO `fb_admins` (`id`, `fb_id`, `aktivlik`) VALUES
(1, 100000514690739, 1),
(3, 2147483647112, 1);



-- ---------------------------------------------------------
--
-- Table structure for table : `home_page`
--
-- ---------------------------------------------------------

CREATE TABLE `home_page` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `image_arge` varchar(255) NOT NULL,
  `image_kalite` varchar(255) NOT NULL,
  `image_marka` varchar(255) NOT NULL,
  `image_footer` varchar(255) NOT NULL,
  `image_about` varchar(255) NOT NULL,
  `image_about1` varchar(255) NOT NULL,
  `image_about2` varchar(255) NOT NULL,
  `image_about3` varchar(255) NOT NULL,
  `image_contact` varchar(255) NOT NULL,
  `image_sunar1` varchar(255) NOT NULL,
  `image_sunar2` varchar(255) NOT NULL,
  `image_sunar3` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `home_page`
--

INSERT INTO `home_page` (`id`, `image_arge`, `image_kalite`, `image_marka`, `image_footer`, `image_about`, `image_about1`, `image_about2`, `image_about3`, `image_contact`, `image_sunar1`, `image_sunar2`, `image_sunar3`) VALUES
(1, 'ar-ge-1561022361.png', '_kalite-1562423663.png', '__makalarimiz-01-1562646842.png', '___zavod-istehsalat-1810x380-1562646575.png', '____hakkimizda-1000x370-1562646745.png', '_____5-1562404194.jpg', '______6-1562404194.jpg', '_______7-1562404194.jpg', '________contact-us-1562653987.png', '_________takviye-edici-1562423389.png', '__________dermokozmetik-kozmetik-1562423389.png', '___________fason-uretimi-1562423389.png');



-- ---------------------------------------------------------
--
-- Table structure for table : `image_cropper`
--
-- ---------------------------------------------------------

CREATE TABLE `image_cropper` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



-- ---------------------------------------------------------
--
-- Table structure for table : `langs`
--
-- ---------------------------------------------------------

CREATE TABLE `langs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `position` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `active` int(11) NOT NULL,
  `flag` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `langs`
--

INSERT INTO `langs` (`id`, `name`, `full_name`, `position`, `status`, `active`, `flag`) VALUES
(2, 'en', 'En', 2, 0, 0, 'United-Kingdom-flag-64.png'),
(3, 'ru', 'Ru', 3, 0, 1, 'Russia-Flag-64.png'),
(20, 'az', 'AZ', 1, 1, 1, 'Azerbaijan-Flag-64.png');



-- ---------------------------------------------------------
--
-- Table structure for table : `letters`
--
-- ---------------------------------------------------------

CREATE TABLE `letters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `subject` varchar(250) NOT NULL,
  `message` text NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp(),
  `seen_by_admin` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;



-- ---------------------------------------------------------
--
-- Table structure for table : `links`
--
-- ---------------------------------------------------------

CREATE TABLE `links` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_en` varchar(100) NOT NULL,
  `name_ru` varchar(100) NOT NULL,
  `name_az` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `target` varchar(255) NOT NULL,
  `position` int(11) NOT NULL,
  `active` int(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `links`
--

INSERT INTO `links` (`id`, `name_en`, `name_ru`, `name_az`, `url`, `target`, `position`, `active`) VALUES
(1, 'ghjghjghjg', 'ujfufcyuj', '', 'asd', 'asd', 1, 1);



-- ---------------------------------------------------------
--
-- Table structure for table : `logs`
--
-- ---------------------------------------------------------

CREATE TABLE `logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL COMMENT 'kim daxil olubsa onun ID sidir. yeni iwci daxil olsa iwcinin, mudur daxil olsa mudurun, admin daxil olsa adminin',
  `action` varchar(50) NOT NULL,
  `amount` double NOT NULL,
  `note` varchar(255) NOT NULL,
  `data_id` int(11) NOT NULL,
  `old_value` varchar(50) NOT NULL,
  `new_value` varchar(50) NOT NULL,
  `datetime` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



-- ---------------------------------------------------------
--
-- Table structure for table : `menus`
--
-- ---------------------------------------------------------

CREATE TABLE `menus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `name_en` varchar(255) NOT NULL,
  `name_ru` varchar(255) NOT NULL,
  `name_az` varchar(255) NOT NULL,
  `text_en` text NOT NULL,
  `text_ru` text NOT NULL,
  `text_az` text NOT NULL,
  `link` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL DEFAULT '0',
  `icon_code` varchar(255) NOT NULL,
  `important` tinyint(1) NOT NULL DEFAULT 0,
  `position` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=61 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `menus`
--

INSERT INTO `menus` (`id`, `parent_id`, `name_en`, `name_ru`, `name_az`, `text_en`, `text_ru`, `text_az`, `link`, `image`, `icon_code`, `important`, `position`, `active`) VALUES
(7, 0, 'HOME', 'Главная', 'Ana səhifə', '', '', '', 'home', 'rom7417-1511072377.jpg', '', 0, 1, 1),
(10, 0, 'About', 'О враче', 'Həkim haqqında', '', '', '<p>Tibb elmleri namizədi, alqoloq - ağrı həkimi, doktor Vüsal Eyvazov 2000-ci ildə Azərbaycan Tibb Universitetini bitirmiş, 2000-2005-ci ildə Rusiya Federesiyasının Sankt-Peterburq şəhərində Ordinatura və aspirantura təhsili alaraq ixtisaslaşmış və tibb elmləri namizədi elmi dərəcəsini almışdır. 2005-ci ildən isə Azərbaycana qayıtmış və Mərkəzi Neftçilər xəstəxanasında anestezioloq kimi fəaliyyət göstərmişdir. 2011-ci ildən etibarən isə Baku Medical Plazada Anesteziologiya və reanimasiya şöbəsinin müdiri vəzifəsində çalışır. Tibb elimləri namizədi, doktor Vüsal Eyvazov Türkiyənin İzmir şəhərində Ege Universitetinin Tibb fakultəsində isə Alqoloji bilim dalında ixtisaslaşmış, Alqoloq - Ağrı həkimi ixtisasına yiyələnmişdir. Alqologiya ilə bağlı bir çox elmi konfranslarda, kurslarda olan Vüsal həkim 2017-ci ildə Azərbaycanda ilk dəfə<span style="color: #0000ff;"> Ağrı Müalicə Mərkəzini</span> yaratmışdır.</p>', 'haqqimizda', 'fiziki-reabilitasiya-hekimi-1608048993.png', '', 0, 2, 1),
(30, 0, 'Qalereya', 'Галерея', 'Qalereya', '', '', '', '##', 'fiziki-reabilitasiya-hekimi-1608311673.png', '', 0, 5, 1),
(29, 0, 'Əlaqə', 'Контакты', 'Əlaqə', '', '', '', 'elaqe', 'reabilitasyon-1608047365.png', '', 0, 8, 1),
(25, 0, 'Rəylər', 'Комментарии', 'Rəylər', '', '', '', 'reyler', 'fiziki-reabilitasiya-hekimi-1608057987.png', '', 0, 6, 0),
(26, 30, 'Videoqalereya', 'Видеогалерея', 'Videoqalereya', '', '', '', 'videoqalereya', 'fiziki-reabilitasiya-hekimi-1608474806.png', '', 0, 1, 1),
(28, 30, 'Fotoqalereya', 'Фотогалерея', 'Fotoqalereya', '', '', '', 'albom', 'fiziki-reabilitasiya-hekimi-1608474788.png', '', 0, 2, 1),
(59, 0, '', '', 'Müayinələr', '', '', '', 'xidmetler', 'fiziki-reabilitasiya-hekimi-1608058280.png', '', 0, 3, 1),
(60, 0, '', '', 'Müalicə üsulları', '', '', '', 'metodlar', 'fiziki-reabilitasiya-hekimi-1608058300.png', '', 0, 4, 1),
(35, 0, '', 'Блог', 'Blog', '', '', '', 'bloq', 'fiziki-reabilitasiya-hekimi-1610793083.png', '', 0, 7, 1);



-- ---------------------------------------------------------
--
-- Table structure for table : `methods`
--
-- ---------------------------------------------------------

CREATE TABLE `methods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_en` varchar(100) NOT NULL,
  `name_ru` varchar(100) NOT NULL,
  `name_az` varchar(255) NOT NULL,
  `short_text_en` text NOT NULL,
  `short_text_ru` text NOT NULL,
  `short_text_az` text NOT NULL,
  `full_text_en` text NOT NULL,
  `full_text_ru` text NOT NULL,
  `full_text_az` text NOT NULL,
  `image` varchar(100) NOT NULL DEFAULT '0',
  `position` int(11) NOT NULL,
  `active` int(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `methods`
--

INSERT INTO `methods` (`id`, `name_en`, `name_ru`, `name_az`, `short_text_en`, `short_text_ru`, `short_text_az`, `full_text_en`, `full_text_ru`, `full_text_az`, `image`, `position`, `active`) VALUES
(2, '', 'Трансфораминальная эпидуральная стероидная инъекция', 'Nevrolojik xəstələrin Reabilitasyasi', '', 'Трансфораминальная эпидуральная стероидная терапия используется для контроля боли в случаях грыжи диска (разрыв дисков в шейных и поясничных отделах), смещения диска. Во время этого метода лечения препарат вводится в болеобразующий нерв и околонервную область с помощью специальной иглы. Это метод, нацеленный на лечение нервов. Пациенты, страдающие от боли в области шеи, груди, спины, верхних и нижних конечностях и нервных расстройств, могут быть избавлены от болей с помощью этого нехирургического метода лечения.', '', '', '<p style="text-align: left;">Трансфораминальная эпидуральная стероидная терапия используется для контроля боли в случаях грыжи диска (разрыв дисков в шейных и поясничных отделах), смещения диска. Во время этого метода лечения препарат вводится в болеобразующий нерв и околонервную область с помощью специальной иглы. Это метод, нацеленный на лечение нервов. Пациенты, страдающие от боли в области шеи, груди, спины, верхних и нижних конечностях и нервных расстройств, могут быть избавлены от болей с помощью этого нехирургического метода лечения.</p>', '', 'fizik-tedavi-ve-rehabilitasyon-5db560e53aa86-1608232007.jpg', 7, 1),
(22, '', '', 'Ortopedik Və Nevrolojik Əməliyatlardan sonraki Reabilitasya', '', '', '', '', '', '', 'ortopedik-ve-nevrolojik-emeliyatlardan-sonra-reabilitasya-1610477346.png', 5, 1),
(5, '', 'Внутрисуставная инъекция стволовых клеток', 'Cupping massaj - Hicama nədir?', '', 'Метод стволовых клеток, который начали использовать при лечении непроходящих и хронических болей суставов, основан на замещении больных клеток в организме здоровыми клетками. Стволовые клетки – клетки в нашем организме, которые чаще всего встречаются в жировой ткани и могут менять свою форму. Эти клетки получают от пациента путём липоксации, затем пропустив через специальный фильтр, вводятся в сустав больного. Эти стволовые клетки, которые вводятся в сустав, спустя время превращаются в поврежденный хрящ, и все жалобы пациента проходят по мере выздоровления. Этим способом пациенты избавляются от эндопротеза (операция искусственного сустава). Обратите внимание, что после процедуры боль пациента в первый месяц полностью проходит. Через 6-8 месяцев изношенные суставы уже восстанавливаются. Это также становится очевидным на рентгеновском снимке. Для пациентов, страдающих артрозом колена, тазобедренного сустава, плеча, этот метод практически луч жизни.', '"Hacamat, əsrlər boyu alternativ təbabətdə bir müalicə forması olaraq istifadə edilmişdir. Son illərdə yenidən populyarlaşan hacamat ilə əlaqədar hələ çox sual var."', '', '<p>Метод стволовых клеток, который начали использовать при лечении непроходящих и хронических болей суставов, основан на замещении больных клеток в организме здоровыми клетками. Стволовые клетки &ndash; клетки в нашем организме, которые чаще всего встречаются в жировой ткани и могут менять свою форму. Эти клетки получают от пациента путём липоксации, затем пропустив через специальный фильтр, вводятся в сустав больного. Эти стволовые клетки, которые вводятся в сустав, спустя время превращаются в поврежденный хрящ, и все жалобы пациента проходят по мере выздоровления. Этим способом пациенты избавляются от эндопротеза (операция искусственного сустава). Обратите внимание, что после процедуры боль пациента в первый месяц полностью проходит. Через 6-8 месяцев изношенные суставы уже восстанавливаются. Это также становится очевидным на рентгеновском снимке. Для пациентов, страдающих артрозом колена, тазобедренного сустава, плеча, этот метод практически луч жизни.</p>', '<h1 style="text-align: left;"><span style="font-size: 18px;">Hicama-Hacamat</span></h1>\n<p style="text-align: left;"><span style="font-size: 18px;">"Hicama, əsrlər boyu alternativ təbabətdə bir müalicə forması olaraq istifadə edilmişdir. Son illərdə yenidən populyarlaşan hacamat ilə əlaqədar hələ çox sual var."</span></p>\n<h1 style="text-align: left;"><span style="font-size: 18px;">Hicama nədir?</span></h1>\n<p style="text-align: left;"><span style="font-size: 18px;">Hacamat, əsrlər boyu sağlamlıq metodu olaraq istifadə edilən və indi alternativ tibb adı <img style="margin: 10px; float: right;" src="/images/upload/image/hicamanin%20qiymeti.jpg" alt="" width="500" height="334" />altında olan bir müalicə formasıdır. Xüsusi stəkanların köməyi ilə qan toplama prosesi olan hacamat, bədənin öz-özünə çıxara bilmədiyi toksinlərin vakuumla təmizlənməsi prosesidir.</span></p>\n<h1 style="text-align: left;"><span style="font-size: 18px;">Hicamanın - hacamatın faydaları nələrdir?</span></h1>\n<p style="text-align: left;"><span style="font-size: 18px;">Hacamat, toksinlərin, ağır metalların, istifadə edilən dərmanların və bədənin ata bilməyəcəyi hormonal qidaların bədəndə qalıqlarını təmizləməyə kömək edir. İmmunitet sistemini gücləndirir, bədən müqavimətini artırır. Ödem atılmağına kömək edir. Qan istehsalından məsul olan orqanları və beyinin funksiyalarını stimullaşdırır. Boyun və bel yırtığı, oynaq ağrıları, ürək, qaraciyər və psixoloji xəstəliklərin müalicəsini dəstəkləyir. Görmə qabiliyyətini artırır. Unutqanlığı və diqqət çatışmazlığını müalicə edir. Damarları təmizləyir, xolesterolu azaldır. Sonsuzluq, reproduktiv problemlər, cinsi zəiflik kimi problemlərin müalicəsində istifadə olunur.</span></p>\n<h1 style="text-align: left;"><span style="font-size: 18px;">Hicama necə edilir?</span></h1>\n<p style="text-align: left;"><span style="font-size: 18px;">Hacamat tətbiq olunacaq hissə təyin olunduqdan sonra dəri neştər köməyi ilə cızılır. Cızıqlanmış dəriyə vakuum şüşə qoyulur və çirkli qandan təmizlənir. Hacamat evdə olduğu kimi klinikalarda da edilə bilər. Hacamat etdirdiyiniz şəxsin bir mütəxəssis olduğuna əmin olun.</span></p>\n<h1 style="text-align: left;"><span style="font-size: 18px;">Hicama kimlərə tətbiq edilə bilməz?</span></h1>\n<p style="text-align: left;"><span style="font-size: 18px;">Hacamat çox faydalı bir müalicə üsulu olsa da, mütəxəssislər bunu hər kəs üçün doğru hesab etmirlər. Kardiostimulyatora sahib olanlara, qan tutanlara, kimyəvi terapiya alanlara, həddindən artıq həyəcanlılara, orqan köçürülənlərə və hamilə qadınlara tövsiyə edilmir.</span></p>\n<h1 style="text-align: left;"><span style="font-size: 18px;">Hicamanın ziyanı varmı?</span></h1>\n<p style="text-align: left;"><span style="font-size: 18px;">Hacamat mütəxəssiz olmayan insanlar tərəfindən səhv müalicə üsullarında və gigiyenik olmayan mühitdə həyata keçirilərsə, bir çox sağlamlıq problemi yarada bilər.</span></p>\n<p style="text-align: left;"><span style="font-size: 18px;">Bunlardan bəzilərini aşağıdakı kimi göstərmək olar;</span></p>\n<p style="text-align: left;"><span style="font-size: 18px;">dəri infeksiyaları, dəri yaraları və qançırlar, ağrılar.</span></p>\n<h1 style="text-align: left;">Hicamanın qiyməti</h1>\n<p style="text-align: left;"><span style="font-size: 18px;">Hicama proseduru bir neçə seasn həyata keçirilə bilər. Bu səbəbdən Hicamanın qiyməti ilə bağlı ətraflı məlumat üçün <a href="tel:+994 (055) 690 18 04">+994 (055) 690 18 04</a> nömrəsi ilə əlaqə saxlaya bilərsiniz.</span></p>', 'hacamat-nedir-hicama-nedir-1611517026.jpg', 3, 1),
(9, '', 'Ломберная торакальная и цервикальная фасетная денервация', 'Quru iynələmə (Dry needlingle) müalicəsi', '', 'Фасеточные суставы - это суставы, которые обеспечивают подвижность и эластичность позвоночника. Эти суставы могут потерять свое обычное строение и вызывать хроническую боль как вследствие нашей работы, так и в результате старения и травм. Следует отметить, что в Ломберных, Торакальных и Цервикальных фасеточных суставах нервы, распространяющие боли, в проблемной области могут быть выявлены и разрушены с использованием радиофрекансной энергии. Радиофрекансный фасетный суставной синдром применяется к пациентам с болями в спине при движении назад, наклонах налево и направо и поворотах влево и вправо, с болями, усиливающимися в нижних отделах, в особенности при поворотах в постели во время ночного сна.', 'İstifadə olunan iynələrdə heç bir dərman olmadığı üçün bu üsul “Quru İynələmə və ya Dry Needling” adlanır.\nQuru iynə terapiyası elmi bir müalicə metodudur və dünyada əzələ-skelet ağrısı üçün geniş istifadə olunur.', '', '<p>Фасеточные суставы - это суставы, которые обеспечивают подвижность и эластичность позвоночника. Эти суставы могут потерять свое обычное строение и вызывать хроническую боль как вследствие нашей работы, так и в результате старения и травм. Следует отметить, что в Ломберных, Торакальных и Цервикальных фасеточных суставах нервы, распространяющие боли, в проблемной области могут быть выявлены и разрушены с использованием радиофрекансной энергии. Радиофрекансный фасетный суставной синдром применяется к пациентам с болями в спине при движении назад, наклонах налево и направо и поворотах влево и вправо, с болями, усиливающимися в нижних отделах, в особенности при поворотах в постели во время ночного сна.</p>', '<h1 style="text-align: justify;"><span style="font-size: 18px;"><strong>QURU İYNƏLƏMƏ (DRY NEEDLİNG) NƏDİR?</strong></span></h1>\n<p style="text-align: justify;"><span style="font-size: 18px;">İstifadə olunan iynələrdə heç bir dərman olmadığı üçün bu üsul &ldquo;Quru İynələmə və ya <strong><em> Dry Needling</em></strong>&rdquo; adlanır. Quru iynə terapiyası elmi bir müalicə metodudur və dünyada əzələ-skelet ağrısı üçün geniş istifadə olunur.</span></p>\n<p style="text-align: justify;"><span style="font-size: 18px;"><img style="float: right; margin: 10px;" src="/images/upload/image/QURU%20%C4%B0YNELEME.jpg" alt="" width="300" height="300" /></span></p>\n<h2 style="text-align: justify;"><span style="font-size: 18px;"><strong>Quru iynələmə (dry needling) proseduru necə tətbiq olunur?</strong></span></h2>\n<p style="text-align: justify;"><span style="font-size: 18px;">Bu üsulda akupunktur iynələri olaraq bilinən müxtəlif uzunluqlu çox incə və xüsusi iynələr istifadə olunur.</span></p>\n<p style="text-align: justify;"><span style="font-size: 18px;">İynə ilə ağrılı əzələlərdə ağrıya səbəb olan &ldquo;trigger point&rdquo; və ya "xüsusi nöqtələrə" daxil olunur.</span></p>\n<p style="text-align: justify;"><span style="font-size: 18px;">Lazım gələrsə, həmin bölgəyə iynə ilə elektrik cərəyanı verilə bilər.</span></p>\n<p style="text-align: justify;"><span style="font-size: 18px;">Quru iynələmə müalicəsinin təsirləri nələrdir?</span></p>\n<p style="text-align: justify;"><span style="font-size: 18px;"> &bull; Quru iynələmə ilə spazmın aradan qaldırılır və yarım qalmış yaxşılaşma prosesi yenidən başladılır. </span></p>\n<p style="text-align: justify;"><span style="font-size: 18px;">&bull; Bunun səbəbi hüceyrələrdəki elektrik yüklərinin yenidən qurulması və fiziki müdaxilədir.</span></p>\n<p style="text-align: justify;"><span style="font-size: 18px;">&bull; İynələrin əzələlərinin stimullaşdırılması sayəsində bədənin özünü bərpası mexanizmi işə düşür.</span></p>\n<p style="text-align: justify;"><span style="font-size: 18px;">&bull; Bu səbəbdən ağrını deyil, xəstəliyi müalicə edir. Xəstəlik sağaldıqca ağrı öz-özünə yox olur.</span></p>\n<h2 style="text-align: justify;"><span style="font-size: 18px;"><strong>Quru iynələmə hansı xəstəliklərdə, hansı ağrılarda təsirli olur?</strong></span></h2>\n<p style="text-align: justify;"><span style="font-size: 18px;">Bel və boyun yırtığı</span></p>\n<p style="text-align: justify;"><span style="font-size: 18px;">Əzələ spazmları</span></p>\n<p style="text-align: justify;"><span style="font-size: 18px;">Miyofasiyal Ağrı Sindromu</span></p>\n<p style="text-align: justify;"><span style="font-size: 18px;">Fibromiyalji</span></p>\n<p style="text-align: justify;"><span style="font-size: 18px;">Sinüzit</span></p>\n<p style="text-align: justify;"><span style="font-size: 18px;">Çiyin ağrısı</span></p>\n<p style="text-align: justify;"><span style="font-size: 18px;">Dondurulmuş çiyin</span></p>\n<p style="text-align: justify;"><span style="font-size: 18px;">Epikondilit "Tenis Dirsəyi və Golferin Dirsəyi"</span></p>\n<p style="text-align: justify;"><span style="font-size: 18px;">Diz ağrısı</span></p>\n<p style="text-align: justify;"><span style="font-size: 18px;">Chondromalacia Patella</span></p>\n<p style="text-align: justify;"><span style="font-size: 18px;">Duruş pozğunluğuna görə ağrı</span></p>\n<p style="text-align: justify;"><span style="font-size: 18px;">Baş ağrısı</span></p>\n<p style="text-align: justify;"><span style="font-size: 18px;">Miqren</span></p>\n<h2 style="text-align: justify;"><span style="font-size: 18px;"><strong>Quru iynə müalicəsi ağrılıdırmı?</strong></span></h2>\n<p style="text-align: justify;"><span style="font-size: 18px;">İstifadə olunan iynələr saç qədər incədir və bu prosedur ağrılı deyil.</span></p>\n<h2 style="text-align: justify;"><span style="font-size: 18px;"><strong>Quru iynələmə müalicəsinin yan təsirləri varmı?</strong></span></h2>\n<p style="text-align: justify;"><span style="font-size: 18px;">Heç bir dərman tətbiq edilmədiyi üçün yan təsiri yoxdur.</span></p>\n<p style="text-align: justify;"><span style="font-size: 18px;">Quru iynələmə prosedurunu tətbiqi təhlükəlidirmi?</span></p>\n<p style="text-align: justify;"><span style="font-size: 18px;">Anatomiya bilməyən və bu işin mütəxəssisi olmayan insanlar tərəfindən həyata keçirilən prosedurlar ciddi fəsadlara yol aça bilər. Dərinizin altında onlarla sinir və damar olduğunu unutmayın. Hansı iynənin hansı sahəyə hansı bucaq altında istifadə edilməli olduğu sualının cavabı yalnız bu işin mütəxəssisləri tərəfindən verilə bilər.</span></p>', 'quruiyenelememuumlalicesi-1610789216.jpg', 2, 1),
(10, '', 'Диагностический блок', 'Graston teknik (miyosaial gevşetme )', '', 'Для определения местоположения боли у пациента осуществляется диагностический блок. Если боли пациента проходят в течение 2-3 дней после данной процедуры, врач по боли назначает пациенту второй долгосрочный метод лечения, такой как радиофреканс, эпидуральные и стероидные инъекции. Диагностический блок может быть использован для выявления боли в областях головы, шеи, спины и т.д.', 'Graston metodu nədir?\n\nGraston metodu, zədələnmiş toxumaların effektiv aşkarlanmasına və müalicəsinə imkan verən alət dəstəyi ilə yumşaq toxuma (Instrument asssisted soft tissue mobilization – IASTM) üsuludur. Bu patentləşdirilmiş texnika əksər (kəskin və ya xroniki) əzələ-iskelet problemləri üçün dəstəkləyici terapiya kimi istifadə olunur. Graston texnikası, fiziki terapevtlər tərəfindən müalicə olunan bəzi xəstəliklərin əzələ hazırlığı proseslərində performans və koordinasiyanı artırmaq üçün də istifadə edilir. Graston texnikasının əsas məqsədi zədələnmiş yumşaq toxuma üçün daha yaxşı bir şəfa mühiti təmin etmək və xəstənin ağrısını azaltmaqdır.\n\nGraston metodu hansı xəstəliklərin müalicəsində təsirli olur?', '', '<p>Для определения местоположения боли у пациента осуществляется диагностический блок. Если боли пациента проходят в течение 2-3 дней после данной процедуры, врач по боли назначает пациенту второй долгосрочный метод лечения, такой как радиофреканс, эпидуральные и стероидные инъекции. Диагностический блок может быть использован для выявления боли в областях головы, шеи, спины и т.д.</p>', '<h1><span style="font-size: 18px;">Graston metodu nədir?</span></h1>\n<p><span style="font-size: 18px;">Graston metodu, zədələnmiş toxumaların effektiv aşkarlanmasına və müalicəsinə imkan verən alət dəstəyi ilə yumşaq toxuma (Instrument asssisted soft tissue mobilization &ndash; IASTM) üsuludur. Bu patentləşdirilmiş texnika əksər (kəskin və ya xroniki) əzələ-iskelet problemləri üçün dəstəkləyici terapiya kimi istifadə olunur. Graston texnikası, fiziki terapevtlər tərəfindən müalicə olunan bəzi xəstəliklərin əzələ hazırlığı proseslərində performans və koordinasiyanı artırmaq üçün də istifadə edilir. Graston texnikasının əsas məqsədi zədələnmiş yumşaq toxuma üçün daha yaxşı bir şəfa mühiti təmin etmək və xəstənin ağrısını azaltmaqdır.</span></p>\n<h1><span style="font-size: 18px;">Graston metodu hansı xəstəliklərin müalicəsində təsirli olur?</span></h1>\n<p><span style="font-size: 18px;">Graston metodu aşağıdakı xəstəliklərin və şikayətlərin müalicəsində təsirli olur:</span></p>\n<h2><span style="font-size: 18px;">Boyun ağrısı</span></h2>\n<h2><span style="font-size: 18px;">Çiyin ağrısı</span></h2>\n<h2><span style="font-size: 18px;">Bel ağrısı</span></h2>\n<h2><span style="font-size: 18px;">Qolfçu dirsəyi</span></h2>\n<h2><span style="font-size: 18px;">Tennisçi dirsəyi</span></h2>\n<h2><span style="font-size: 18px;">Carpal tunel sindromu</span></h2>\n<h2><span style="font-size: 18px;">Servikal ağrı</span></h2>\n<h2><span style="font-size: 18px;">Fibromiyalji</span></h2>\n<h2><span style="font-size: 18px;">Əzələ gərginliyi</span></h2>\n<p><span style="font-size: 18px;">Graston metodu Terapiyasının faydaları</span></p>\n<p><span style="font-size: 18px;">Ümumi müalicə müddətinin qısaldılmasını təmin edir.</span></p>\n<p><span style="font-size: 18px;">Daha sürətli reabilitasiya və bərpanı təmin edir.</span></p>\n<p><span style="font-size: 18px;">İltihab əleyhinə dərmanlara olan ehtiyacını azaldır.</span></p>\n<p><span style="font-size: 18px;">Qalıcı olduğu düşünülən xroniki xəstəlikləri müalicə edir.</span></p>\n<p><span style="font-size: 18px;">Graston metodu, kəskin və xroniki zədələnmələr və ya əməliyyatdan sonra yumşaq toxuma zədələnmələri nəticəsində yaranan funksiya itkisini bərpa etmək üçün olduqca təsirli bir terapiya üsuludur.</span></p>\n<h2><span style="font-size: 18px;">Graston metodu necə işləyir?</span></h2>\n<p><span style="font-size: 18px;">Graston metodu,alət və masaj əzələ toxumalarını uzatmaq və rahatlatmaq üçün birlikdə istifadə olunur, qan axınının artmasına və zədələnmiş toxumalarda hərəkəti bərpa etməyə kömək edir.Fiziki müalicədə istifadə edilən Graston metodu, reabilitasiya hərəkətləri ilə istifadə edildikdə yumşaq toxuma disfunksiyasının səbəb olduğu hərəkət məhdudiyyətlərini düzəltmək üçün təsirli ola biləcək uğurlu tətbiqdir.</span></p>\n<p><span style="font-size: 18px;">Nəticələr dəyişə bilsə də, xəstələr müalicənin birinci və ya ikinci həftəsinin sonunda ağrı səviyyəsində və ya hərəkət səviyyəsində yaxşılaşma olduğunu asanlıqla görə bilərlər. Təcrübəli fiziki terapevtlər tərəfindən Graston metodun düzgün tətbiqi, yumşaq toxuma zədələnmələri ilə əlaqəli narahatlığı azaltmağa və beləliklə xəstələrin ağrısız bir həyat sürməsinə kömək edə bilər.</span></p>', 'reabilitasiyadagrastometodu-1610477137.jpg', 1, 1),
(11, '', 'Лечение боли с помощью эпидуроскопии', 'Mulligan Manual terapiya', '', 'Эпидуроскопия, применяемая при болях в поясничном, шейном и спинном отделах, является безопасным, нехирургическим и эффективным методом лечения. Таким образом, можно вводить лекарство в любой отдел позвоночника. Основной причиной использования эпидуроскопии при лечении боли является устранение спаек спинного мозга, которые способствуют хронической боли по всему позвоночнику. Таким образом, пациент может полностью избавиться от этих болей в течение 15-20 минут. Обратите внимание, что эпидуроскопия в основном применяется к пациентам, прошедшим операцию по удалению грыжи в поясничном и шейном отделах, однако с постоянными болями в области поясницы, спины, шеи без хирургического вмешательства.', 'Manual terapiya onurğa xəstəliklərini müalicə edən kompleks üsullardan ibarət müalicə növüdür. Onurğanın bel və boyun nahiyəsində bəzən ağrılar əmələ gəlir. Bu onurğanın və disklərin sürüşməsi, qabarması nəticəsində baş verir.', '', '<p>Эпидуроскопия, применяемая при болях в поясничном, шейном и спинном отделах, является безопасным, нехирургическим и эффективным методом лечения. Таким образом, можно вводить лекарство в любой отдел позвоночника. Основной причиной использования эпидуроскопии при лечении боли является устранение спаек спинного мозга, которые способствуют хронической боли по всему позвоночнику. Таким образом, пациент может полностью избавиться от этих болей в течение 15-20 минут. Обратите внимание, что эпидуроскопия в основном применяется к пациентам, прошедшим операцию по удалению грыжи в поясничном и шейном отделах, однако с постоянными болями в области поясницы, спины, шеи без хирургического вмешательства.</p>', '<p>&nbsp;</p>\n<p><span style="font-size: 18px;">Manual terapiya onurğa xəstəliklərini müalicə edən kompleks üsullardan ibarət müalicə növüdür. Onurğanın bel və boyun nahiyəsində bəzən ağrılar əmələ gəlir. Bu onurğanın və disklərin sürüşməsi, qabarması nəticəsində baş verir.</span><br /><span style="font-size: 18px;"> MT-nın istifadəsinə göstəriş &ndash; onurğanın və ətraf oynaqlarının xəstəlikləridi ki, bu halda, dərman preparatlarının dozasını azaltmağa və ya hətta onları tamamilə ləğv etməyə imkan verərək, manual müalicə təsirləri zamanı güclü müsbət nəticə əldə edilir. Digər bərpa tədbirləri ilə kompleksdə (fiziki tapşırıqlar, masaj, fizioterapevtik prosedurlar və s.) MT, patoloji sindromların aradan qaldırılmasını, onurğa və ətraf oynaqların funksiyalarının normallaşmasını və pasiyentlərin fəaliyyət qabiliyyətinin bərpasını sürətləndirir.</span></p>\n<p><span style="font-size: 18px;">MT-nın məqsədi &ndash; onurğa və ətrafların oynaqlarının biomexanikasının pozuntularının aradan qaldırılması, onurğa hərəkət seqmentlərinin, oynaqların və bütövlükdə dayaq-hərəkət aparatın normal hərəkətliliyinin bərpası, dinamik stereotipin yenidən qurulmasından ibarətdir.Məlumdur ki, müəyyən əzələ qruplarında tonusun pozuntusu ətraf oynaqlarda funksional blokadalarının yaranmasına zəmin yaradır. Bu, yalnız məhz oynağın deyil, həm də onu əhatə edən əzələlərin, vətərlərin və bağların hərəkətliliyini məhdudlaşdırır. Tədricən bütün bu toxumalarda distrofik dəyişikliklər artır, trofikanın pisləşməsi baş verir ki, bu da zədələnmiş əzələlərin qısaldılmasına gətirib çıxarır. Oynaqlarda əvvəlcə funksional kontrakturalar yaranır ki, bunları aktiv müalicə prosesində ləğv etmək olar, ağır hallarda isə &ndash; orqanik kontrakturalar əmələ gəlir, bu halda oynaq tamamilə hərəkətsiz olur.</span></p>\n<h1><span style="font-size: 18px;">Manual terapiya aşağıdakı hallarda effektli olur:</span></h1>\n<ul>\n<li><span style="font-size: 18px;">osteoxondroz</span></li>\n<li><span style="font-size: 18px;">radikulit</span></li>\n<li><span style="font-size: 18px;">protruziya</span></li>\n<li><span style="font-size: 18px;">onurğa yırtığı</span></li>\n<li><span style="font-size: 18px;">qamət pozğunluğu</span></li>\n<li><span style="font-size: 18px;">skalioz</span></li>\n<li><span style="font-size: 18px;">baş ağrıları</span></li>\n<li><span style="font-size: 18px;">miqren</span></li>\n</ul>\n<h1><span style="font-size: 18px;">Manual terapiya aşağıdakı hallarda əks təsir edir.</span></h1>\n<ul>\n<li><span style="font-size: 18px;">qan-damar xəstəlikləri</span></li>\n<li><span style="font-size: 18px;">yüksək hərarət</span></li>\n<li><span style="font-size: 18px;">yüksək təzyiq</span></li>\n<li><span style="font-size: 18px;">onurğanın iltihabı xəstəlikləri və s.</span></li>\n</ul>', 'mulligan-manual-terapiya-1608231808.jpg', 4, 1),
(12, '', 'GON блок от боли при мигрени', 'Müalicəvi idman', '', 'GON (окципитальный блок) - это метод блокирования нервов, распространяющих головную боль, анестезирующими препаратами и Радиофрекансным методом. Благодаря этому методу боль в нервной системе, которая вызывает боль, блокируется, что приводит к утиханию болей. Блок GON применяется в область большого затылочного нерва задней части головы сидячего пациента под местной анестезией. Процедура, которая занимает в общей сложности 45 минут, может дать результат для многих пациентов с первого сеанса, но некоторым может понадобиться 2 или 3 сеанса. Блокада GON применяется к пациентам, которые не хотят принимать лекарства, страдают от мигрени, пациентам с сильной головной болью, те люди которым употребление медикаментов запрещено, людям с печеночной или почечной недостаточностью, кормящим матерям, беременным женщинам, людям, которые не могут принимать обезболивающие из-за расстройства системы пищеварения.', '', '', '<p style="text-align: justify;">GON (окципитальный блок) - это метод блокирования нервов, распространяющих головную боль, анестезирующими препаратами и Радиофрекансным методом. Благодаря этому методу боль в нервной системе, которая вызывает боль, блокируется, что приводит к утиханию болей. Блок GON применяется в область большого затылочного нерва задней части головы сидячего пациента под местной анестезией. Процедура, которая занимает в общей сложности 45 минут, может дать результат для многих пациентов с первого сеанса, но некоторым может понадобиться 2 или 3 сеанса. Блокада GON применяется к пациентам, которые не хотят принимать лекарства, страдают от мигрени, пациентам с сильной головной болью, те люди которым употребление медикаментов запрещено, людям с печеночной или почечной недостаточностью, кормящим матерям, беременным женщинам, людям, которые не могут принимать обезболивающие из-за расстройства системы пищеварения.</p>', '', 'muumlalicevi-idman-1608231936.jpg', 6, 1);



-- ---------------------------------------------------------
--
-- Table structure for table : `money_balance`
--
-- ---------------------------------------------------------

CREATE TABLE `money_balance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cash_desk_id` int(11) NOT NULL,
  `sold_to_user_id` int(11) NOT NULL,
  `sold_program_id` int(11) NOT NULL,
  `client_name` varchar(255) NOT NULL,
  `amount` int(11) NOT NULL,
  `period` int(11) NOT NULL,
  `payment_type` tinyint(1) NOT NULL COMMENT '0=>income,1=>out',
  `note` varchar(255) NOT NULL,
  `datetime` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



-- ---------------------------------------------------------
--
-- Table structure for table : `namaz_time`
--
-- ---------------------------------------------------------

CREATE TABLE `namaz_time` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subh` varchar(255) NOT NULL,
  `gun` varchar(255) NOT NULL,
  `zohr` varchar(255) NOT NULL,
  `esr` varchar(255) NOT NULL,
  `megrib` varchar(255) NOT NULL,
  `isha` varchar(255) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `namaz_time`
--

INSERT INTO `namaz_time` (`id`, `subh`, `gun`, `zohr`, `esr`, `megrib`, `isha`, `date`) VALUES
(1, '05:15', 'aaa', '13:45', '', '21:36', '00:46', '2013-07-06');



-- ---------------------------------------------------------
--
-- Table structure for table : `news`
--
-- ---------------------------------------------------------

CREATE TABLE `news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `datetime` int(11) NOT NULL,
  `name_en` varchar(255) NOT NULL,
  `name_ru` varchar(255) NOT NULL,
  `name_az` varchar(255) NOT NULL,
  `keywords_en` varchar(255) NOT NULL,
  `keywords_ru` varchar(255) NOT NULL,
  `keywords_az` varchar(255) NOT NULL,
  `short_text_en` varchar(500) NOT NULL,
  `short_text_ru` varchar(500) NOT NULL,
  `short_text_az` text NOT NULL,
  `full_text_en` text NOT NULL,
  `full_text_ru` text NOT NULL,
  `full_text_az` text NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `read_count` int(11) NOT NULL DEFAULT 0,
  `type` tinyint(255) DEFAULT 1 COMMENT '1 => news, 2 => campaign',
  `comment_count` int(11) NOT NULL DEFAULT 0,
  `flash` tinyint(1) NOT NULL,
  `active` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `kateqoriya` (`category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `category_id`, `author_id`, `datetime`, `name_en`, `name_ru`, `name_az`, `keywords_en`, `keywords_ru`, `keywords_az`, `short_text_en`, `short_text_ru`, `short_text_az`, `full_text_en`, `full_text_ru`, `full_text_az`, `image`, `read_count`, `type`, `comment_count`, `flash`, `active`) VALUES
(3, 0, 0, 1610704931, '', '', 'Bel fəqərə sürüşməsi nədir? Necə yaranır?', '', '', '', '', '', 'Lomber sürüşmə, onurğa sümüklərinin fərqli səbəblərdən irəli və ya geri sürüşdüyü zaman', '', '', '<div class="kvgmc6g5 cxmmr5t8 oygrvhab hcukyx3x c1et5uql ii04i59q">\n<div dir="auto"><span style="font-size: 18px;">Lomber sürüşmə, onurğa sümüklərinin fərqli səbəblərdən irəli və ya geri sürüşdüyü zaman meydana gələn bir xəstəlikdir. Normalda bir sıra düzülmüş fəqərələr, aralarındakı oynaq və birləşdirici toxumalarla bir-birinə bağlanır. Hər vertebra arasındakı bu toxumalara ön hissədəki disk deyilir və faset oynaqları arxa hissədəki toxumalardır. Fəqərələrdən biri spondilolistez kimi təyin olunan bel dəyişikliyinin iştirakı ilə irəli və ya geri hərəkət edir. Bu sürüşmə hərəkəti sayəsində onurğa, onurğa beyni və onurğa içindəki sinirlər arasındakı toxumalar sıxılır. Beləliklə, aşağı ətraflar, ayaq və barmaqlarda, xüsusən də beldə ağrı, yanma və uyuşma kimi nevroloji simptomlar baş verir.</span></div>\n</div>\n<div class="o9v6fnle cxmmr5t8 oygrvhab hcukyx3x c1et5uql ii04i59q">\n<h2 dir="auto"><span style="font-size: 18px;">Belə sürüşməsi necə müalicə olunur?</span></h2>\n</div>\n<div class="o9v6fnle cxmmr5t8 oygrvhab hcukyx3x c1et5uql ii04i59q">\n<div dir="auto"><span style="font-size: 18px;">Xəstə bel ağrısı şikayəti ilə həkimə müraciət etdikdə ətraflı bir məlumat alınır və sonra fiziki müayinə aparılır. Həkimin istəyi ilə aparılan radioloji görüntüləmə ilə lomber yerdəyişmə diaqnozu qoyulur. Müalicə lomber sapma növünə və şikayətlərə görə təşkil edilir. Bəzi hallarda qarın və bel əzələlərini gücləndirən istirahət və ya idman proqramları müalicə üçün kifayət edə bilər. Bel dislokasiyasının şiddətindən asılı olaraq həkim xəstəni fiziki müalicə və reabilitasiya şöbəsinə yönləndirə bilər və onun üçün xüsusi bir proqram təklif edə bilər. Dərmanla müalicə sonrakı seçimdir. Çox inkişaf etmiş hallarda onurğa sütununun əvvəlki quruluşuna gəlməsi üçün cərrahi əməliyyat tələb oluna bilər.</span></div>\n</div>\n<div class="o9v6fnle cxmmr5t8 oygrvhab hcukyx3x c1et5uql ii04i59q">\n<div dir="auto"><span style="font-size: 18px;">Belinizdə ağrı varsa, sağlamlığınız üçün müayinələrdən keçməyi gecikdirməyin.</span></div>\n</div>\n<div class="o9v6fnle cxmmr5t8 oygrvhab hcukyx3x c1et5uql ii04i59q">&nbsp;</div>', 'bel-feqere-surusmesi-1610791909.jpg', 0, 1, 0, 0, 1),
(23, 0, 0, 1610793776, '', '', 'Diz protezi əməliyyatından sonra reabilitasiya nə üçün edilməlidir?', '', '', '', '', '', 'Diz protezi əməliyyatından sonra reabilitasiya nə üçün edilməlidir?', '', '', '<div dir="auto"><span style="font-size: 18px;">Diz protezi əməliyyatından sonra reabilitasiya nə üçün edilməlidir?</span></div>\n<div dir="auto"><span style="font-size: 18px;">Diz oynaqlarını lazımı istiqamələrdə hərəkət etdirilməsini təmin etmək</span></div>\n<div dir="auto"><span style="font-size: 18px;">Dizi idarə edən kuadriseps əzələsi və ətrafdakı digər əzələləri gücləndirmək</span></div>\n<div dir="auto"><span style="font-size: 18px;">Hərəkətsizliyin səbəb olacağı əzələ zəifliyi, ayaqda şişkinlik , damar tıxanması kimi istənilməyən vəziyyətlərin qarşısını almaq.</span></div>\n<div dir="auto"><span style="font-size: 18px;">Əməliyyat olunan xəstənin funksional vəziyyətinin yaxşılaşdırılması, müstəqil fəaliyyət göstərməsi və həyat keyfiyyətinin yüksəldilməsi üçün.</span></div>\n<div dir="auto"><span style="font-size: 18px;">Əməliyyat sonrası erkən dövrdə xəstələr ağrı və gərginliyi azaltmaq üçün dizlərini əyilmiş vəziyyətdə saxlamağa üstünlük verə bilərlər, lakin bu əlverişsizdir. İstirahət zamanı xəstə dizinin düz olmasına diqqət yetirməlidir, çünki dizin əyilmiş vəziyyətdə donması gələcəkdə ağrı və yeriş pozuntularına səbəb olacaqdır. Bu səbəbdən diz protezi əməliyyatı edilən xəstənin erkən dövründə diz əyilmə məşqləri tədricən artırılmalı, digər tərəfdən əyilən ayağın istirahət edərkən bükülməsinin qarşısı alınmalı və ayağ düz vəziyyəti istirahətdə saxlanılmalıdır.</span></div>', 'sunioynaqemeliyyatindansonrareabilitasiya-1610793775.jpg', 0, 1, 0, 0, 1),
(21, 0, 0, 1610793157, '', '', 'Manual terapiya nədir?', '', '', '', '', '', 'Manual terapiya yalnız əllərdən istifadə edərək tətbiq olunan müalicə metodudur.', '', '', '<p dir="auto"><span style="font-size: 18px;">Manual terapiya yalnız əllərdən istifadə edərək tətbiq olunan müalicə metodudur.<br />Manual terapiya yalnız ağrı olan hissəni əhatə etmir eyni zamanda ağrının qaynaqlandığı nöqtənin təyin edilməsində və o bölgəyə təsir edərək ağrıları kökündən aradan qaldırmasına kömək edir.</span></p>\n<div dir="auto"><span style="font-size: 18px;">Manual terapiyada oynaq, əzələ və sinir sisteminin öz təbii fiziologiyasına və anatomiyasına qayıtması əsas məqsədlərdən biridir. Bu terapiyada qan dövranı sistemi yaxşılaşdırılır və bədənin özünü müalicə mexanizmi aktivləşir.</span></div>', 'manuel-terapiya-1610793213.jpg', 0, 1, 0, 0, 1),
(19, 0, 0, 1610792525, '', '', 'Əzələ spazmı nədir?', '', '', '', '', '', 'Əzələ spazmı əzələləri əhatə edə bilən ağrılı, ani baş verən sancılardır. Demək olar ki, hər kəsdə büruzə verə bilər. Bədənin bir çox əzələlərinə təsir edə, eyni zamanda fərqli simptomlara səbəb ola bilər.', '', '', '<p dir="auto"><span style="font-size: 18px;">spazmı əzələləri əhatə edə bilən ağrılı, ani baş verən sancılardır. Demək olar ki, hər kəsdə büruzə verə bilər. Bədənin bir çox əzələlərinə təsir edə, eyni zamanda fərqli simptomlara səbəb ola bilər. Ən çox görülən növ skelet əzələlərindəki spazmlardır. Ümumiyyətlə əzələ zədələnməsi, həddindən artıq hərərkətdə, bədəndəki elektrolit balansının pozulması və bədənin su itirməsindən qaynaqlansa da da, digər səbəblərdən də inkişaf edə bilər. Skelet əzələlərindən başqa uşaqlıq, bağırsaq, öd yolları və damar divarları kimi orqanlar da kramplara-spazmlara məruz qala bilər. Əzələ spazmlarının əksəriyyəti müvəqqəti olsa da, bəzən mütəmadi olaraq təkrarlana bilər. Bu vəziyyətdə şəxs mütləq tibbi yardım almalıdır.</span></p>\n<h2 dir="auto"><span style="font-size: 18px;">Əzələ spazmlarını yaradan bəzi səbəblər:</span></h2>\n<div dir="auto"><span style="font-size: 18px;">Mineral çatışmazlığı: Əzələ spazmları kalsium, kalium, sodyum və maqnezium çatışmazlığı olan insanlarda tez-tez biruzə verir.</span></div>\n<div dir="auto"><span style="font-size: 18px;">Yetərli olmayan qan axını</span></div>\n<div dir="auto"><span style="font-size: 18px;"> Sinir sıxılması</span></div>\n<div id="gtx-trans" style="position: absolute; left: 297px; top: 219.438px;">&nbsp;</div>', 'ezele-spazmi-1610792656.jpg', 0, 1, 0, 0, 1),
(20, 0, 0, 1610792810, '', '', 'İnsult reabilitasiası nədir?', '', '', '', '', '', 'İnsult - beyin qan dövranının kəskin pozulmasıdır. İ', '', '', '<p><span style="font-size: 18px;">İnsult - beyin qan dövranının kəskin pozulmasıdır. İnsult nəticəsində - ifliclər, udmanın pisləşməsi, müvazinətsizlik, keyləşmələr, ağrılar, bəzi ağır xəstələrdə qeyri-iradi sidik və ya nəcis ifrazı, nitq çətinliyi, depressiya, hövsələsizlik və əsəbilik kimi bir çox pozğunluqlar meydana çıxır. Insult keçirmiş xəstələrin reabilitasiyasi xəstələrə insultdan sonra mümkün ola bilən ən yaxşı nəticəni əldə etməyə imkan verərək ömrü uzadır və ağırlaşmadan sonra itirilmiş-pisləşmiş funksiyalarını yaxşılaşdıraraq gündəlik həyata uyğunlaşmağa kömək edir. Reabilitasiyaya nə qədər gec başlanılarsa, bərpa da bir o qədər çətinləşir. Bu səbəbdən erkən dönəmdə bir Fizioterapevtə müraciət etmək çox vacibdir. </span></p>', 'insultsonrasireabilitasiya-1610792842.jpg', 0, 1, 0, 0, 1),
(22, 0, 0, 1610793250, '', '', 'Ağrılar üçün quru iynələmə müalicəsi nədir?', '', '', '', '', '', 'Ağrılar üçün quru iynələmə müalicəsi nədir?', '', '', '<div dir="auto"><span style="font-size: 18px;">Dry needling (Quru iynələmə) müalicəsi, hər hansı bir dərman olmadan yalnız iynə ilə əzələ və yumşaq toxumaların xəbərdar edilməsinə əsaslanan bir müalicə metodudur. Nazikliyi səbəbi ilə prosedur zamanı heç bri ağrı hissi yaratmayan bu iynələrin əsas nöqtələri həssas ya da trigger nöqtələrdir.</span></div>\n<div dir="auto"><span style="font-size: 18px;">Hansı xəstəliklərdə quru iynə terapiyası tətbiq olunur?</span></div>\n<div dir="auto"><span style="font-size: 18px;">- Trigger nöqtə xəstəliyi (miofassiyal ağrı sindromu)</span></div>\n<div dir="auto"><span style="font-size: 18px;">- Fibromiyalgiya</span></div>\n<div dir="auto"><span style="font-size: 18px;">- Bel və boyun kirəclənməsi ilə bağlı ağrılar</span></div>\n<div dir="auto"><span style="font-size: 18px;">- Bel və boyun yırtıqları</span></div>\n<div dir="auto"><span style="font-size: 18px;">- Tendinit, xroniki tennisçı dirsək</span></div>\n<div dir="auto"><span style="font-size: 18px;">- Ağrılı çiyin</span></div>', 'quru-iyneleme-1610793310.jpg', 0, 1, 0, 0, 1);



-- ---------------------------------------------------------
--
-- Table structure for table : `news_gallery`
--
-- ---------------------------------------------------------

CREATE TABLE `news_gallery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `name_en` varchar(255) NOT NULL,
  `name_ru` varchar(255) NOT NULL,
  `name_az` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `video_url` varchar(255) NOT NULL,
  `position` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;



-- ---------------------------------------------------------
--
-- Table structure for table : `our_cash_desks`
--
-- ---------------------------------------------------------

CREATE TABLE `our_cash_desks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `payment_type` tinyint(1) NOT NULL COMMENT '0=>income,1=>out,2=>both',
  `important` tinyint(1) NOT NULL,
  `position` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



-- ---------------------------------------------------------
--
-- Table structure for table : `partners`
--
-- ---------------------------------------------------------

CREATE TABLE `partners` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_en` varchar(255) NOT NULL,
  `name_ru` varchar(255) NOT NULL,
  `name_az` varchar(255) NOT NULL,
  `short_text_en` varchar(500) NOT NULL,
  `short_text_ru` varchar(500) NOT NULL,
  `short_text_az` text NOT NULL,
  `full_text_en` text NOT NULL,
  `full_text_ru` text NOT NULL,
  `full_text_az` text NOT NULL,
  `image` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL,
  `position` int(11) NOT NULL,
  `active` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



-- ---------------------------------------------------------
--
-- Table structure for table : `patients`
--
-- ---------------------------------------------------------

CREATE TABLE `patients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_en` varchar(255) NOT NULL,
  `name_ru` varchar(255) NOT NULL,
  `name_az` varchar(255) NOT NULL,
  `title_en` varchar(255) NOT NULL,
  `title_ru` varchar(255) NOT NULL,
  `title_az` varchar(255) NOT NULL,
  `video_url` varchar(255) NOT NULL,
  `position` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`id`, `name_en`, `name_ru`, `name_az`, `title_en`, `title_ru`, `title_az`, `video_url`, `position`, `active`) VALUES
(3, '', 'Износ хряща тазобедренного сустава', 'Fizioterapevt Dr. Ramazan Nasırlı', '', 'Отзыв Ирады ханум, страдающей от износа хряща тазобедренного сустава, о стволовых клетках', 'Fiziki reabilitasiyada həyata keçirilən prosedurlar', 'https://www.youtube.com/watch?v=TCwH3rYiWPk', 2, 1),
(12, '', 'Диагностический фаcетный блок', 'Fizioterapevt Dr. Ramazan Nasırlı', '', 'Отзыв пациента, страдающего болями в области головы и шеи, после процедуры', 'Hacettepe məzunu Fizioterapevt Dr. Ramazan Nasırlını yaxından tanıyın', 'https://www.youtube.com/watch?v=JsPWFZys0zc', 1, 0),
(13, '', 'Эпидуральный катетер с перманентной помпой (туннельный эпидуральный катетер)', 'Fizioterapevt Dr. Ramazan Nasırlı', '', 'Отзыв пациента, страдающего от раковых болей, после процедуры', 'Fizioterapiya və reabilitasiyaya kimlər müraciət edə bilərlər?', 'https://www.youtube.com/watch?v=iVGOV6vvs4A&ab_channel=Dr.RamazanNas%C4%B1rl%C4%B1', 3, 1),
(15, '', '', 'Fizioterapevt Dr. Ramazan Nasırlı', '', '', 'Türkiyədən Azərbaycana dəvət almış #Fizioterapevt Ramazan Nəsirli kimdir?', 'https://www.youtube.com/watch?v=QKFdcSQCpGk', 4, 1);



-- ---------------------------------------------------------
--
-- Table structure for table : `payments`
--
-- ---------------------------------------------------------

CREATE TABLE `payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `worker_id` int(11) NOT NULL,
  `program_id` int(11) NOT NULL,
  `cash_desk_id` int(11) NOT NULL,
  `client_name` varchar(255) NOT NULL,
  `amount` double NOT NULL,
  `payment_type` tinyint(1) NOT NULL COMMENT '0=>income,1=>out',
  `note` varchar(255) NOT NULL,
  `datetime` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



-- ---------------------------------------------------------
--
-- Table structure for table : `photo_albums`
--
-- ---------------------------------------------------------

CREATE TABLE `photo_albums` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_en` varchar(255) NOT NULL,
  `name_ru` varchar(255) NOT NULL,
  `name_az` varchar(255) NOT NULL,
  `text_en` text NOT NULL,
  `text_ru` text NOT NULL,
  `text_az` text NOT NULL,
  `image` varchar(255) NOT NULL DEFAULT '0',
  `position` int(11) NOT NULL,
  `datetime` int(11) NOT NULL DEFAULT 0,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;



-- ---------------------------------------------------------
--
-- Table structure for table : `photo_albums_gallery`
--
-- ---------------------------------------------------------

CREATE TABLE `photo_albums_gallery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `name_en` varchar(255) NOT NULL,
  `name_ru` varchar(255) NOT NULL,
  `name_az` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL DEFAULT '0',
  `video_url` varchar(255) NOT NULL DEFAULT '0',
  `position` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=61 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `photo_albums_gallery`
--

INSERT INTO `photo_albums_gallery` (`id`, `parent_id`, `name_en`, `name_ru`, `name_az`, `image`, `video_url`, `position`, `active`) VALUES
(17, 10, '', '', 'Ramazan ayına özəl keçirilən pulsuz müayinə kampaniyasından fotolar.', '610052433723837533730668617988953305251840o-1581597205.jpg', 0, 1, 1),
(18, 10, '', '', 'Ramazan ayına özəl keçirilən pulsuz müayinə kampaniyasından fotolar.', '611981633723839067063842842669236373946368o-1581597383.jpg', 0, 14, 1),
(19, 10, '', '', 'Ramazan ayına özəl keçirilən pulsuz müayinə kampaniyasından fotolar.', '61223503372383926706382234667229117939712o-1581597383.jpg', 0, 13, 1),
(20, 10, '', '', 'Ramazan ayına özəl keçirilən pulsuz müayinə kampaniyasından fotolar.', '614273863723838600397226320647101709549568o-1581597383.jpg', 0, 12, 1),
(21, 10, '', '', 'Ramazan ayına özəl keçirilən pulsuz müayinə kampaniyasından fotolar.', '614366723723839800397103588721973565325312o-1581597383.jpg', 0, 11, 1),
(22, 10, '', '', 'Ramazan ayına özəl keçirilən pulsuz müayinə kampaniyasından fotolar.', '614768323723838100397277494152937162145792o-1581597383.jpg', 0, 10, 1),
(23, 10, '', '', 'Ramazan ayına özəl keçirilən pulsuz müayinə kampaniyasından fotolar.', '615169573723835700397512117145884511698944o-1581597383.jpg', 0, 9, 1),
(24, 10, '', '', 'Ramazan ayına özəl keçirilən pulsuz müayinə kampaniyasından fotolar.', 'pulsuzmuayinekampaniyasi-1581597383.jpg', 0, 8, 1),
(25, 10, '', '', 'Ramazan ayına özəl keçirilən pulsuz müayinə kampaniyasından fotolar.', 'pulsuzmuayinekampaniyasi1-1581597383.jpg', 0, 7, 1),
(26, 10, '', '', 'Ramazan ayına özəl keçirilən pulsuz müayinə kampaniyasından fotolar.', 'pulsuzmuayinekampaniyasi2-1581597383.jpg', 0, 6, 1),
(27, 10, '', '', 'Ramazan ayına özəl keçirilən pulsuz müayinə kampaniyasından fotolar.', 'pulsuzmuayinekampaniyasi3-1581597383.jpg', 0, 5, 1),
(28, 10, '', '', 'Ramazan ayına özəl keçirilən pulsuz müayinə kampaniyasından fotolar.', 'pulsuzmuayinekampaniyasi4-1581597383.jpg', 0, 4, 1),
(29, 10, '', '', 'Ramazan ayına özəl keçirilən pulsuz müayinə kampaniyasından fotolar.', 'pulsuzmuayinekampaniyasi5-1581597383.jpg', 0, 3, 1),
(30, 10, '', '', 'Ramazan ayına özəl keçirilən pulsuz müayinə kampaniyasından fotolar.', 'xronikiagrilarinmualicesi-1581597383.jpg', 0, 2, 1),
(31, 11, '', '', 'Kök hüceyrə prosedurundan fotolar', 'kokhuceyreproseduru-1581597810.jpg', 0, 15, 1),
(32, 11, '', '', 'Kök hüceyrə prosedurundan fotolar', 'kokhuceyreproseduru1-1581597810.jpg', 0, 16, 1),
(33, 16, '', '', 'Ağrı həkimi - Alqoloq Vüsal Eyvazov Mingəçevirdə xroniki ağrılardan əziyyət çəkən xəstələri qəbul etdi', 'agrihekimialqoloq-1583234858.jpg', 0, 1, 1),
(34, 16, '', '', 'Ağrı həkimi - Alqoloq Vüsal Eyvazov Mingəçevirdə xroniki ağrılardan əziyyət çəkən xəstələri qəbul etdi', 'agrihekimivusaleyvazov-1583234858.jpg', 0, 1, 1),
(35, 16, '', '', 'Ağrı həkimi - Alqoloq Vüsal Eyvazov Mingəçevirdə xroniki ağrılardan əziyyət çəkən xəstələri qəbul etdi', 'ciyinagrilarininmuayinesi-1583234858.jpg', 0, 1, 1),
(36, 16, '', '', 'Ağrı həkimi - Alqoloq Vüsal Eyvazov Mingəçevirdə xroniki ağrılardan əziyyət çəkən xəstələri qəbul etdi', 'dizagrilarininmuayinesi-1583234858.jpg', 0, 1, 1),
(37, 16, '', '', 'Ağrı həkimi - Alqoloq Vüsal Eyvazov Mingəçevirdə xroniki ağrılardan əziyyət çəkən xəstələri qəbul etdi', 'dizbelagrilarininmuayinesi-1583234858.jpg', 0, 1, 1),
(38, 16, '', '', 'Ağrı həkimi - Alqoloq Vüsal Eyvazov Mingəçevirdə xroniki ağrılardan əziyyət çəkən xəstələri qəbul etdi', 'dizmrtsi-1583234858.jpg', 0, 1, 1),
(39, 16, '', '', 'Ağrı həkimi - Alqoloq Vüsal Eyvazov Mingəçevirdə xroniki ağrılardan əziyyət çəkən xəstələri qəbul etdi', 'muayine-1583234858.jpg', 0, 1, 1),
(40, 16, '', '', 'Ağrı həkimi - Alqoloq Vüsal Eyvazov Mingəçevirdə xroniki ağrılardan əziyyət çəkən xəstələri qəbul etdi', 'vusaleyvazovmingecevirde-1583234858.jpg', 0, 1, 1),
(41, 16, '', '', 'Ağrı həkimi - Alqoloq Vüsal Eyvazov Mingəçevirdə xroniki ağrılardan əziyyət çəkən xəstələri qəbul etdi', 'vusaleyvazovmuayinede-1583234858.jpg', 0, 1, 1),
(42, 17, '', '', 'Dr. Vüsal Eyvazov "Səni axtarıram" verilişində xroniki ağrılardan əziyyət çəkən insanların şikayətlərini dinləyir', 'dr-vusal-eyvazov-seni-axtariram-verilisinde-1583516594.jpg', 0, 1, 1),
(43, 17, '', '', 'Dr. Vüsal Eyvazov "Səni axtarıram" verilişində xroniki ağrılardan əziyyət çəkən insanların şikayətlərini dinləyir', 'dr-vusal-eyvazov-seni-axtariram-verilisinde1-1583516594.jpg', 0, 1, 1),
(44, 17, '', '', 'Dr. Vüsal Eyvazov "Səni axtarıram" verilişində xroniki ağrılardan əziyyət çəkən insanların şikayətlərini dinləyir', 'dr-vusal-eyvazov-seni-axtariram-verilisinde2-1583516594.jpg', 0, 1, 1),
(45, 17, '', '', 'Dr. Vüsal Eyvazov "Səni axtarıram" verilişində xroniki ağrılardan əziyyət çəkən insanların şikayətlərini dinləyir', 'dr-vusal-eyvazov-seni-axtariram-verilisinde3-1583516594.jpg', 0, 1, 1),
(46, 17, '', '', 'Dr. Vüsal Eyvazov "Səni axtarıram" verilişində xroniki ağrılardan əziyyət çəkən insanların şikayətlərini dinləyir', 'dr-vusal-eyvazov-seni-axtariram-verilisinde5-1583516594.jpg', 0, 1, 1),
(47, 17, '', '', 'Dr. Vüsal Eyvazov "Səni axtarıram" verilişində xroniki ağrılardan əziyyət çəkən insanların şikayətlərini dinləyir', 'dr-vusal-eyvazov-seni-axtariram-verilisinde44-1583516594.jpg', 0, 1, 1),
(48, 18, '', '', 'Oynaq yeyilmələri üçün kök hüceyrə müalicəsi', 'alinankokhuceyreler-1583931441.jpg', 0, 1, 1),
(49, 18, '', '', 'Oynaq yeyilmələri üçün kök hüceyrə müalicəsi', 'kokhuceyre-1583931441.jpg', 0, 1, 1),
(50, 18, '', '', 'Oynaq yeyilmələri üçün kök hüceyrə müalicəsi', 'kokhuceyremualicesi-1583931441.jpg', 0, 1, 1),
(51, 18, '', '', 'Oynaq yeyilmələri üçün kök hüceyrə müalicəsi', 'kokhuceyremualicesiqarindanpiy-1583931441.jpg', 0, 1, 1),
(52, 18, '', '', 'Oynaq yeyilmələri üçün kök hüceyrə müalicəsi', 'kokhuceyreproseduru-1583931441.jpg', 0, 1, 1),
(53, 19, '', '', 'Beldə disk yırtığı səbəbi ilə yaranan ağrıların aradan qaldırılması üçün həyata keçirilən Radiofrekansla Dorsal Qanqlion Bloku prosedurundan fotolar', '1006718775914467114667681096506658202320896n-1590567606.jpg', 0, 1, 1),
(54, 19, '', '', 'Beldə disk yırtığı səbəbi ilə yaranan ağrıların aradan qaldırılması üçün həyata keçirilən Radiofrekansla Dorsal Qanqlion Bloku prosedurundan fotolar', '1008021175914465181334542755558713971441664n-1590567606.jpg', 0, 1, 1),
(55, 19, '', '', 'Beldə disk yırtığı səbəbi ilə yaranan ağrıların aradan qaldırılması üçün həyata keçirilən Radiofrekansla Dorsal Qanqlion Bloku prosedurundan fotolar', 'belagrilarininemeliyyatsizmualicesi-1590567606.jpg', 0, 1, 1),
(56, 19, '', '', 'Beldə disk yırtığı səbəbi ilə yaranan ağrıların aradan qaldırılması üçün həyata keçirilən Radiofrekansla Dorsal Qanqlion Bloku prosedurundan fotolar', 'diskyirtigi-1590567606.jpg', 0, 1, 1),
(57, 19, '', '', 'Beldə disk yırtığı səbəbi ilə yaranan ağrıların aradan qaldırılması üçün həyata keçirilən Radiofrekansla Dorsal Qanqlion Bloku prosedurundan fotolar', 'diskyirtigininemeliyyatsizmualicesi-1590567606.jpg', 0, 1, 1),
(58, 19, '', '', 'Beldə disk yırtığı səbəbi ilə yaranan ağrıların aradan qaldırılması üçün həyata keçirilən Radiofrekansla Dorsal Qanqlion Bloku prosedurundan fotolar', 'dorsalqanqlionbloku-1590567606.jpg', 0, 1, 1),
(59, 19, '', '', 'Beldə disk yırtığı səbəbi ilə yaranan ağrıların aradan qaldırılması üçün həyata keçirilən Radiofrekansla Dorsal Qanqlion Bloku prosedurundan fotolar', 'steroidinyeksiyasi-1590567606.jpg', 0, 1, 1),
(60, 19, '', '', 'Beldə disk yırtığı səbəbi ilə yaranan ağrıların aradan qaldırılması üçün həyata keçirilən Radiofrekansla Dorsal Qanqlion Bloku prosedurundan fotolar', 'vusaleyvazov-1590567606.jpg', 0, 1, 1);



-- ---------------------------------------------------------
--
-- Table structure for table : `products`
--
-- ---------------------------------------------------------

CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` varchar(255) NOT NULL,
  `author_id` int(11) NOT NULL,
  `datetime` int(11) NOT NULL,
  `name_en` varchar(255) NOT NULL,
  `name_ru` varchar(255) NOT NULL,
  `name_az` varchar(255) NOT NULL,
  `keywords_en` varchar(255) NOT NULL,
  `keywords_ru` varchar(255) NOT NULL,
  `keywords_az` varchar(255) NOT NULL,
  `short_text_en` varchar(500) NOT NULL,
  `short_text_ru` varchar(500) NOT NULL,
  `short_text_az` text NOT NULL,
  `full_text_en` text NOT NULL,
  `full_text_ru` text NOT NULL,
  `full_text_az` text NOT NULL,
  `image` varchar(255) NOT NULL,
  `read_count` int(11) NOT NULL DEFAULT 0,
  `comment_count` int(11) NOT NULL DEFAULT 0,
  `flash` tinyint(1) NOT NULL,
  `active` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `kateqoriya` (`category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=62 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `category_id`, `author_id`, `datetime`, `name_en`, `name_ru`, `name_az`, `keywords_en`, `keywords_ru`, `keywords_az`, `short_text_en`, `short_text_ru`, `short_text_az`, `full_text_en`, `full_text_ru`, `full_text_az`, `image`, `read_count`, `comment_count`, `flash`, `active`) VALUES
(2, '5-9-14', 0, 1562397387, 'ADAFUL 4', 'ADAFUL 4', '', '', '', '', '', '', '', '<p><strong>ADAFUL 4</strong> - consists of vitamin-mineral complexes and this product is involved in the regulation of many metabolic processes in the body. Eliminates problems with iodine and folic acid deficiency. It improves mood, calms, eliminates fatigue. Helps normal pregnancy, is involved in the development of the nervous system of the fetus, reduces uterine contractility and convulsive contraction of peripheral muscles.</p>\n\n<p><strong>Release form:</strong> N 30 capsules</p>', '<p><strong>ADAFUL 4 -</strong> состоит из витаминно-минеральных комплексов и участвует в регуляции многих обменных процессов в организме. Устраняет проблемы с дефицитом йода и фолиевой кислоты. Улучшает настроение, успокаивает, устроняет усталость. Помогает нормальному течениию беременности, участвует в развитии нервной системы плода, уменьшает сократительную способность матки и судорожное сокрашение периферических мышц.</p>\n\n<p><strong>Форма выпуска: </strong>№30 капсула</p>', '', 'adaful-4---17-1565007627.07-1565007627.19-1565007627.png', 0, 0, 0, 1),
(3, '5-10', 0, 1562938964, 'ADAKİT', 'ADAKİT', '', '', '', '', '', '', '', '<p><strong>ADAKIT</strong> is a combined product. It is used to treat iron deficient anemia. It acts as a biocatalyst in the body and forms the majority of Hb and other enzymes. It helps to eliminate the iron deficiency required for the synthesis of Hb and other globulin enzymes and stimulates erythropoiesis. Fe + 2 fumarate helps to recover the amount of iron in the blood, together with Fe + 2 transferrin in the blood serum, Hb plays a role in the formation of myoglobin and helps the organism to accumulate in their stores.</p>\n\n<p><strong>Release form:</strong> 30 ml drops</p>', '<p><strong>ADAKİT</strong> комбинированное средство используется для лечения железодефицитной анемии, которая действует как биокатализатор для организмов и является основной частью Hb и других ферментов, которые помогают уменьшить дефицит железа и стимулировать эритропоз, важный для синтеза Hb и других ферментов глобулина. Fe2 + фумарат помогает восстановить количество железа в крови. В сочетании с переносом в сыворотку крови Fe + 2 участвует в образовании Hb, миоглобина и помогает организму накапливаться в депо.</p>\n\n<p><strong>Форма выпуска</strong>: 30 ml капли</p>', '', 'adakit---17-1565007588.07-1565007588.19-1565007588.png', 0, 0, 0, 1),
(4, '3-5-10', 0, 1562941516, 'ADAL+', 'ADAL+', '', '', '', '', '', '', '', '<p><strong>ADAL +</strong> is a combination of vitamins which regulates important metabolic processes in the body. Vitamin D contributes to the absorption of calcium from the intestines, vitamin K2 activates Matrix GLA protein, which is necessary for the absorption of bones and calcium denatat accumulated in blood and tissues. For this reason, ADAL + not only absorbs calcium from the intestines, but also delivers it to the bones. This gives more effective effect on the treatment and prevention of rickets, osteoporosis. ADAL + helps to cure clinical diseases like diabetes, rheumatic diseases, depression and so on.</p>\n\n<p><strong>Release form:</strong> 25 ml spray</p>', '<p><strong>ADAL +</strong> это комбинация витаминов каторая регулирует важные обменные процессы в организме. Витамин D способствует высасывание кальция из кишечника, витамин K2 активирует белок Matrix GLA, который необходим для поглощения костей и дентата кальция, накопленного в крови и тканях. По этой причине АДАЛ + не только поглощает кальций из кишечника, но и доставляет его в кости. Это дает более эффективное влияние на лечение и профилактику рахита, остеопороза. АДАЛ + помогает излечить клиническое заболевания как сахарной диабет, ревматические заболевания, депрессия и так далее.</p>\n\n<p><strong>Форма выпуска</strong>: 25 мл спрей</p>', '', 'adal-17-1565007556.07-1565007556.19-1565007556.png', 0, 0, 0, 1),
(9, '4-7', 0, 1562943472, 'ADELAS', 'ADELAS', '', '', '', '', '', '', '', '<p><strong>ADELAS</strong> has a calming, antimetrical, tocoly effect.<br />It eliminates the symptoms of nausea and vomiting during gastrointestinal, nervous diseases, and also eliminates the symptoms of tonus during pregnancy. The active ingredient of ginger extract inhibits the vomiting reflex. As part of magnesia and vitamin B6 reduces nervous tension and symptoms of neurosis.</p>\n\n<p><strong>Release form: </strong>№20 tablets</p>', '<p><strong>ADELAS</strong> обладает успокаивающим, антиметическим, токолитеским действием. <br />Он устраняет симптомы тошноты и рвоты во время желудочно-кишечных, нервных заболеваний, а также во время беременности устраняет симптомы тонуса. Действующее вещество экстракта имбиря тормозит продимость рвотного рефлекса. В составе магнезиум и витамин В6 уменьшает нервное перенапряжение и симптомы неврозности.</p>\n\n<p><strong>Форма выпуска: </strong>№ 20 таблет</p>', '', 'adelas---17-1565006932.07-1565006932.19-1565006932.png', 0, 0, 0, 1),
(5, '3-5-7-10', 0, 1562941961, 'ADECAL', 'ADECAL', '', '', '', '', '', '', '', '<p><strong>ADECAL</strong> is a complex remedy for rickets and bone injuries, and is also intended to restore calcium deficiency during intensive development. It consists of vitamins and minerals that will regulate ossification processes. At the same time, it eliminates the nervous activity and muscular weakness associated with hypocalcemia.</p>\n\n<p><strong>Release form</strong>: 150 ml syrup</p>', '<p><strong>АDECAL</strong> комплексное средство от рахита и травм костей, а также предназначен для восстановления дефицита кальция при интенсивном развитии. Он состоит из витаминов и минералов, которые будут регулировать процессы окостенения. В то же время устраняет нервную активность и мышечную слабость связанные с гипокальциемией.</p>\n\n<p><strong>Форма выпуска: </strong>150 мл сироп</p>', '', 'adecal-17-1565007521.07-1565007521.19-1565007521.png', 0, 0, 0, 1),
(6, '9-10', 0, 1562942231, 'ADEGAM', 'ADEGAM', '', '', '', '', '', '', '', '<p><strong>ADEGAM</strong> has a nootropic, sedative, neuroprotective, antiepileptic effect. It eliminates the symptoms of hyperactivity, encephalopathy in children, night sleep disorders, memory deficiency and enuresis. Improves the function of nerve cells, increases nerve conduction. Neutralizes symptoms such as neurosis, excitability and tearfulness.</p>\n\n<p><strong>Release form: </strong>120 ml syrup</p>', '<p><strong>ADEGAM</strong> - обладает ноотропным, седативным, нейропротекторным, противоэпилептическим действием.<br /> Он устраняет симптомы гиперактивности, энцефалопатии у детей, нарушения ночного сна, дефицита памяти и энуреза. Улучшает работу нервных клеток, повышает нервную проводимость. Сводит на нет такие симптомы как неврозность, возбудительность и плаксивость.</p>\n\n<p><strong>Форма выпуска</strong>: 120 мл сироп</p>', '', 'adegam-17-1565007491.07-1565007491.-1565007491.19-1565007491.png', 0, 0, 0, 1),
(7, 9, 0, 1562942702, 'ADEGAM PLUS', 'ADEGAM PLUS', '', '', '', '', '', '', '', '<p><strong>ADEGAM PLUS</strong> has a nootropic, cerebroprotective, angioprotective, antiaggregant and microcirculation enhancing effect. It is used to treat disorders of the central nervous system, encephalopathy, sleep disorders, epilepsy, tics, which are observed in various mental disorders. It improves the central and peripheral blood circulation, prevents hypoxia. Improves mood by increasing serotonin level.</p>\n\n<p><strong>Release form: </strong>№30 tablets</p>', '<p><strong>ADEGAM PLUS</strong> обладает ноотропным, церебропротекторным, ангиопротекторным, антиагрегантным и усиливающим микроциркуляцию эффектом. Он используется для лечения расстройств центральной нервной системы, энцефалопатии, нарушений сна, эпилепсии, тиков, энуреза, наблюдаемых при различных психических расстройствах. Улучшает центральную и периферическое кровообращение, предотвращает гипоксию. Улучшает настроение за счет повышения уровня серотонина.</p>\n\n<p><strong>Форма выпуска</strong>: №30 таблет</p>', '', 'adegam-plus---17-1565007362.07-1565007362.19-1565007362.png', 0, 0, 0, 1),
(8, '3-5-7-10', 0, 1562943007, 'ADEL 3', 'ADEL 3', '', '', '', '', '', '', '', '<p><strong>Adel 3</strong> contains vitamin D3 in the form of cholecalciferol, which is 25% more active than ergocalciferol. Adele 3 increases calcium absorption in the intestines and reabsorption of phosphorus in the renal canals. Normalizes the formation of the skeleton, protects the structure of bones. Calcium ions in the blood regulate skeletal muscle tone, myocardial function, transmission of nerve impulses and blood coagulation. Normalizes the function of the thyroid gland, the immune system and affects the production of lymphokines.</p>\n\n<p><strong>Release form</strong>: 15 ml drops</p>', '<p><strong>Adel 3</strong> содержит витамин Д3 в виде холекальциферола, который на 25% более активен, чем эргокальциферол. Адель 3 увеличивает всасывание кальция в кишечнике и реабсорбцию фосфора в почечных каналах. Нормализует формирование скелета, обеспечивает защиту структуры костей. Ионы кальция в крови регулируют тонус скелетных мышц, функции миокарда, передачу нервных импульсов и свертывание крови. Нормализует функцию щитовидной железы, иммунной системы и влияет на выработку лимфокинов.</p>\n\n<p><strong>Форма выпуска</strong>: 15 мл капли</p>', '', 'adel-3-17-1565007127.07-1565007127.19-1565007127.png', 0, 0, 0, 1),
(34, '14-17', 0, 1563780427, 'TAYT VAG 3', 'TAYT VAG 3', '', '', '', '', '', '', '', '<p><strong>TAYT VAG </strong>is a disposable shower for vaginal and external genital hygiene. Due to its unique composition, it has antiseptic, anti-inflammatory, antifungal effects and improves vaginal microflora. Tayt vag reduces burning sensation, itching and unpleasant smell. With regular use, it cleans the vagina from the secretions and restores vaginal microbiocenosis. It is ideally combined with other devices (candles, spirals, gels, etc.).</p>\n\n<p><strong>Release form</strong>: 3 vials</p>', '<p><strong>TAYT VAG </strong> одноразовый душ для гигиены влагалища и наружных половых органов. Благодаря уникальному составу обладает антисептическим, противовоспалительным, противогрибковым и улучшающим микрофлору влагалища действиями. Тайт ваг уменьшает чувства жжения, зуда и неприятный запах. При регулярном применение очищает влагалище от выделений и восстанавливает микробиоциноз вагины. Идеально сочетается с другими средствами (свечи, спирали, гели и т.д).</p>\n\n<p><strong>Форма выпуска: </strong>3 флаконы</p>', '', 'tayt-vag-3-1563782723.png', 0, 0, 0, 1),
(10, '4-8', 0, 1562943803, 'ADELİV', 'ADELİV', '', '', '', '', '', '', '', '<p><strong>ADENLIV</strong> has hepatoprotective, detoxification, antioxidant and membrane-protective action. It removes toxins, nitrogen compounds and salts of heavy metals from the body. Restores damaged liver cells, stimulates the synthesis of phospholipids and proteins, enhances the development of liver cells, restores liver function, prevents the formation of gall bladder and prevents the formation of stones in the gall bladder.</p>\n\n<p><strong>Release form</strong>: № 30 capsule</p>', '<p><strong>ADELİV</strong> обладает гепатопротектoрным, детоксикационном, антиоксидантным и мембранопротекторное действием. Он выводит из организма токсины, азотные соединения и соли тяжелых металлов. Восстанавливает поврежденные клетки печени, стимулирует синтез фосфолипидов и белков, усиливает развитие клеток печени, восстанавливает функцию печени, предотвращает образование желчного пузыря и предотвращает образование камней в желчном пузыре.</p>\n\n<p><strong>Форма выпуска: </strong>№30 капсулы</p>', '', 'adenliv---17-1565006903.07-1565006903.19-1565006903.png', 0, 0, 0, 1),
(11, '9-10', 0, 1562944205, 'ADAKARNİT', 'ADAKARNİT', '', '', '', '', '', '', '', '<p><strong>ADKARNIT </strong>- a complex product with amino acids. Participates in important metabolic processes in the body of the child, accelerates the growth of weight and height, improves psychomotor activity, improves memory and perception. It is recommended for speech disorders, mental retardation, hyperactivity, sleep disorders, lack of weight and height.</p>\n\n<p><strong>Release form</strong>:120 ml syrup</p>', '<p><strong>ADAKARNİT</strong> - комплексное средство с аминными кислотами. Участвует в важных обменных процессах в организме ребенка, ускоряет рост веса и роста, улучшает психомоторную деятельность, улучшает память и восприятие. Рекомендуется при нарушениях речи, умственной отсталости, гиперактивности, нарушениях сна, дефиците веса и роста.</p>\n\n<p><strong>Форма выпуска: </strong>120 мл сироп</p>', '', 'adkarnit-17-1565080925.07-1565080925.19-1565080925.png', 0, 0, 0, 1),
(12, '4-7-10', 0, 1562944542, 'ADOBİL', 'ADOBİL', '', '', '', '', '', '', '', '<p><strong>ADOBİL</strong> is a synbiotic product in drop form. Restores the microflora of the gastrointestinal tract. Due to its liquid content, microflora develops rapidly and prevents constipation, diarrhea, eliminates bloating. It is comfortable and practical to use in children under 1 year helps to relieve bloating and pain.</p>\n\n<p><strong>Release form</strong>: 10 ml drops</p>', '<p>Капли <strong>ADOBİL</strong> являtтся синбиотическим препаратом.восстанавливает микрофлору желудочно-кишечного тракта. Благодаря жидкой формы выпуска микрофлора быстро размножается и предотвращает запоры, диарею , имеет удобное и практическое применение. При применение детям до года уменьшает газообразование и симптомы колики.</p>\n\n<p><strong>Форма выпуска</strong>: 10 мл капли</p>', '', 'adobil-17-1565006022.07-1565006022.19-1565006022.png', 0, 0, 0, 1),
(13, '5-8-14', 0, 1563007148, 'ADOFA', '', '', '', '', '', '', '', '', '<p><strong>ADOFA</strong> regulates reproductive function. It reduces the risk of pregnancy, plays a role in restoring hormone deficiency and contributes to the healthy development of the fetus and nervous system. Provides normal spermatogenesis in men.</p>\n\n<p><strong>Release form</strong>: № 30 tablets</p>', '<p><strong>ADOFA</strong> регулирует репродуктивную функцию. Снижает риск беременности, играет роль в восстановлении гормонального дефицита и способствует здоровому развитию плода и нервной системы. Обеспечивает нормальный сперматогенез у мужчин.</p>\n\n<p><strong>Форма выпуска</strong>: № 30 таблетки</p>', '', 'adofa---17-1565005867.07-1565005867.19-1565005867.png', 0, 0, 0, 1),
(14, 5, 0, 1563007377, 'ADOFER', 'ADOFER', '', '', '', '', '', '', '', '<p><strong>ADOFER</strong> is an antianemic agent that prevents hemoglobin deficiency in the blood. Due to the iron in microcapsules, it is used in the treatment and prevention of iron deficiency anemia. Innovative Adofer in vegetarian capsules, easily absorbable through the gastrointestinal tract and has high efficiency. Adofer negates the following symptoms, such as headache, fatigue, loss of appetite, hair loss and stratification of nails.</p>\n\n<p><strong>Release form</strong>: №30 capsules</p>', '<p><strong>ADOFER</strong> является антианемическим средством, которое предотвращает дефицит гемоглобина в крови. За счет железа находяшегося в микрокапсулах применяется в лечении и профилактике железодефицитной анемии. Инновационный Aрасфасован в вегетарианские капсулы, легковсасывающийся через желудочно-кишечный тракт и обладает высокой эффективностью. Адофер сводит на нет следующие симптомы, такие как головная боль, усталость, потеря аппетита, выпадение волос и раслоение ногтей.</p>\n\n<p><strong>Форма выпуска</strong>: №30 капсулы</p>', '', 'adofer---17-1565005797.07-1565005797.19-1565005797.png', 0, 0, 0, 1),
(15, 5, 0, 1563007741, 'ADOİR-F', 'ADOİR-F', '', '', '', '', '', '', '', '<p><strong>ADOIR-F</strong> is an antianemic agent. The form of fumarate iron is more stable than other iron salts, it does not give the taste of metal in the mouth and has a high bioavailability. one of the other causes of anemia is a lack of folic acid. ADOIR-F due to optimal dose content eliminates folic acid deficiency.</p>\n\n<p><strong>Release form</strong>: №30 tablets</p>', '<p><strong>ADOİR-F</strong> является антианемическим средством. Форма фумарата железа является более стабильной, чем другие соли железа, она не дает вкус металла во рту и обладает высокой биодоступности. одна из других причин анемии, нехватка фолиевой кислоты. Адоир Ф благодаря содержании оптимальной дозы устраняет дефицит фолиевой кислоты.</p>\n\n<p><strong>Форма выпуска</strong>: №30 таблетки</p>', '', 'adoir-f-17-1565005741.07-1565005741.19-1565005741.png', 0, 0, 0, 1),
(16, '5-10', 0, 1563008060, 'ADOİR-K', 'ADOİR-K', '', '', '', '', '', '', '', '<p><strong>ADOİR-K</strong> - the combined agent is used to treat iron deficiency anemia, which acts as a biocatalyst for organisms and is a major part of Hb and other enzymes that help reduce iron deficiency and stimulate erythroposis, important for the synthesis of Hb and other globulin enzymes. Fe2 + fumarate helps restore the amount of iron in the blood. In combination with serum transfer, Fe + 2 participates in the formation of Hb, myoglobin and helps the body accumulate in the storage.</p>\n\n<p><strong>Release form</strong>: 150 ml syrup</p>', '<p><strong>ADOİR-K</strong> комбинированное средство используется для лечения железодефицитной анемии, которая действует как биокатализатор для организмов и является основной частью Hb и других ферментов, которые помогают уменьшить дефицит железа и стимулировать эритропоз, важный для синтеза Hb и других ферментов глобулина. Fe2 + фумарат помогает восстановить количество железа в крови. В сочетании с переносом в сыворотку крови Fe + 2 участвует в образовании Hb, миоглобина и помогает организму накапливаться в депо.</p>\n\n<p><strong>Форма выпуска</strong>: 150 мл сироп</p>', '', 'adoir-k-17-1565005700.07-1565005700.19-1565005700.png', 0, 0, 0, 1),
(17, '4-10-17', 0, 1563009826, 'ADOLA', 'ADOLA', '', '', '', '', '', '', '', '<p><strong>ADOLA</strong> has local anti-inflammatory, antibacterial, antispasmodic, laxative and antihelminthic effects. Due to the plants, Adola is recommended for the treatment of rectal and hemorrhoid fractures due to astringent, wound healing, antibacterial, anti-inflammatory effects.</p>\n\n<p><strong>Release form</strong>: №3 rectal oil 10 ml</p>', '<p><strong>ADOLA </strong>- ето местные противовоспалительные, антибактериальные, спазмолитические, слабительные средства. За счет растений входящий в состав Адола рекомендуется для лечения трещинах прямой кишки и геморроя из-за вяжущих, ранозаживляюших, антибактериальных, протисвоспалительных эффектов.</p>\n\n<p><strong>Форма выпуска</strong>: №3 ректальное масло 10 мл</p>', '', 'adola-17-1565005666.07-1565005666.19-1565005666.png', 0, 0, 0, 1),
(18, '10-17', 0, 1563009841, 'ADOLİN', 'ADOLİN', '', '', '', '', '', '', '', '<p><strong>ADOLİN</strong>, has local anti-inflammatory, antibacterial, antispasmodic, laxative and antihelminthic effects. At the expense of plants, part of it eliminates worms and their eggs.</p>\n\n<p><strong>Release form</strong>: №3 rectal oil 4,5 ml</p>', '<p><strong>ADOLİN,</strong> ето местные противовоспалительные, антибактериальные, спазмолитические, слабительные и противоглистное средства. За счет растений входящий в состав устроняет глисты и их яйца.</p>\n\n<p><strong>Форма выпуска</strong>: №3 ректальное масло 4,5 мл</p>', '', 'adolin-17-1565005621.07-1565005621.19-1565005621.png', 0, 0, 0, 1),
(19, '5-9-10', 0, 1563010241, 'ADOMAX', 'ADOMAX', '', '', '', '', '', '', '', '<p><strong>ADOMAX</strong> - is a comprehensive tool for indispensable nutrition, normal growth and development of the child&single_quot;s body. The presence in the composition of the necessary vitamins in the optimal dose, increase growth and provide intensive development. Adomax also eliminates mental impairment, improving perception and memory in children.</p>\n\n<p><strong>Release form</strong>: 120 syrup</p>', '<p><strong>ADOMAX</strong> - это комплексное средство для незаменимого питания, нормального роста и развития детского организма. Наличие в составе необходимых витаминов в оптимальной дозе, повышают рост и обеспечивают интенсивное развитие. Adomax также устраняет умственные нарушения, улучшая восприятие и память у детей.</p>\n\n<p><strong>Форма выпуска</strong>: 120 мл сироп</p>', '', 'adomax-17-1565005541.07-1565005541.19-1565005541.png', 0, 0, 0, 1),
(20, '5-7-8-10', 0, 1563010553, 'ADOMEGA', 'ADOMEGA', '', '', '', '', '', '', '', '<p><strong>ADOMEGA</strong> is a vitamin-mineral syrup with fish oil but without fish taste (tropical fruit flavor) and smell. It has metabolic, appetite and growth, resistance to infections, improving visual function and mental performance of actions. Doses of all components contained in adomeg are calculated on recommended daily doses. It is used in the treatment of chronic infectious diseases in the rehabilitation period, with hypotrophy and lack of growth, with visual acuity, with hyperactivity and mental retardation.</p>\n\n<p><strong>Release form</strong>: 150 ml syrup</p>', '<p><strong>АDOMEGA</strong>- это витаминно-минеральный сироп с рыбим жиром но без рыбного вкуса (тропический фруктовый вкус) и запаха. Он обладает метаболическим, повыщающий аппетит и рост, устойчивость к инфекциям , улучшающий зрительную функцию и умственную работаспособность действиями. Дозы всех компонентов, содержащихся в адомеге, расчитаны на рекомендованные суточные дозы.используется в лечении хронических инфекционных заболеваях в периоде реабилитации, при гипотрофии и недостаточности роста, при нарушении остроты зрения, при гиперактивности и умственной отсталости.</p>\n\n<p><strong>Форма выпуска</strong>: 150 мл сироп</p>', '', 'adomega-17-1565005493.07-1565005493.19-1565005493.png', 0, 0, 0, 1),
(21, '6-10', 0, 1563012092, 'ADONİN', 'ADONİN', '', '', '', '', '', '', '', '<p><strong>ADONİN</strong> nasal drops are a combination of 2 components with 3% NaCl and N-acetylcysteine. Adonin has anti-inflammatory, mucolytic, antibacterial and anti-allergic effects. Adonin is available for all age groups. Adonin reduces swelling of the mucous membrane, dilutes thick sputum and easily removes it from the nasal cavity. Unlike other nasal drops, Adonin is not addictive and can be used for a long time with allergies.</p>\n\n<p><strong>Release form</strong>: 15 ml nasal drops</p>', '<p><strong>ADONİN</strong> капли для носа представляет собой комбинацию 2-х компонентов с 3% NaCl и N-ацетилцистеином. Адонин обладает противоспалительным, муколитическим, антибактериальным и антиаллергическим действием. При использовании препарата доступны все возрастные группы. Адонин уменьшает отек слизистой оболочки, разжижает густую мокроту и легко удаляет его из полости носа. В отличие от других капель для носа, Адонин не вызывает привыкания и может использоваться в течение длительного времени при аллергиях.</p>\n\n<p><strong>Форма выпуска</strong>: 15 мл капли в нос</p>', '', 'adonin---17-1564581961.07-1564581961.19-1564581961.png', 0, 0, 0, 1),
(22, '6-7-10', 0, 1563013314, 'ADORPİN', 'ADORPİN', '', '', '', '', '', '', '', '<p><strong>ADORPİN</strong>- throat spray with a standardized extract of propolis, extract of mallow and chamomile. It activates immunity against infections, antibacterial effect on microbes, has an antiviral effect against viruses, locally prevents inflammation and reduces pain in the throat. Alcohol-free propolis can be used for allergic patients.</p>\n\n<p><strong>Release form</strong>: 30 ml oral spray</p>', '<p><strong>ADORPİN</strong>&nbsp;- спрей для горла со стандартизированным экстрактом прополиса, экстрактом мальвы и ромашки. Активирует иммунитет против инфекций, антибактериально действует на микробы, оказывает антивирусный эффект против вирусов, локально предотвращает воспаление и уменьшает боль в горле. Очищенный от аллергенов прополис можно применять аллергичным пациентам.</p>\n\n<p><strong>Форма выпуска</strong>: 30 мл оральный спрей</p>', '', 'adorpin---17-1564581923.07-1564581923.19-1564581923.png', 0, 0, 0, 1),
(23, '4-10', 0, 1563013674, 'ADORA', 'ADORA', '', '', '', '', '', '', '', '<p><strong>ADORA</strong> contributes to the natural formation of normal microflora and intestinal function, as well as create an optimal environment in the intestine for the action of digestive enzymes. In addition, they ensure the correct formation of immunity and help reduce the risk of developing infectious diseases, the possibility of manifestation of atopic dermatitis.</p>\n\n<p><strong>Release form</strong>: №10 capsules</p>', '<p><strong>ADORA</strong> способствуют естественному формированию нормальной микрофлоры и функции кишечника, а также создают оптимальную среду в кишечнике для действия пищеварительных ферментов. Кроме того, обеспечивают правильное формирование иммунитета и помогают снизить риск развития инфекционных заболеваний, возможность проявления атопического дерматита.</p>\n\n<p><strong>Форма выпуска</strong>: №10 капсулы</p>', '', 'adora---17-1564581834.07-1564581834.19-1564581834.png', 0, 0, 0, 1),
(24, 3, 0, 1563016653, 'ADORTA', 'ADORTA', '', '', '', '', '', '', '', '<p><strong>ADORTA</strong> is developed to restore the structure of bones and joints, as well as to increase motor function. Glucosamine and chondroitin are the main structural elements of cartilage that ensure the restoration of joints. Prevents degeneration in the joints, reduces inflammation and pain. Adotra provides bone resistance, accelerates the recovery of fractures.</p>\n\n<p><strong>Release form</strong>: №30 tablets</p>', '<p><strong>ADORTA</strong> предназначен для восстановления структуры костей и суставов, а также для увеличения двигательной функции. Глюкозамин и хондроитин являются основными структурными элементами хряща, которые обеспечивают восстановление суставов. Предотвращает дегенерацию в суставах, уменьшает на воспаление и боль. Адотра обеспечивает сопротивление костей, ускоряет восстановление переломов.</p>\n\n<p><strong>Форма выпуска</strong>: №30 таблетки</p>', '', 'adorta---17-1564581753.07-1564581753.19-1564581753.png', 0, 0, 0, 1),
(25, 3, 0, 1563016654, 'ADORTA GEL', 'ADORTA GEL', '', '', '', '', '', '', '', '<p><strong>ADORTA GEL</strong> l is intended for local action of restoring bone and articular structure and increasing its physical activity. Glucosamine and chondroitin are the main structural elements of cartilage that ensure the restoration of joints. It contains complex ingredients to prevent joint degeneration, has anti-inflammatory and analgesic effects. Adotra gel provides bone resistance, accelerates the recovery of fractures.</p>\n\n<p><strong>Release form</strong>: 50 gr gel</p>', '<p><strong>ADORTA ГЕЛЬ</strong> предназначен для местного действие восстановливаюший костно-суставной структуры и повышения ее двигательной активности. Глюкозамин и хондроитин являются основными структурными элементами хряща, которые обеспечивают восстановление суставов. Содержит комплексные ингредиенты для предотвращения дегенерации суставов, обладает противовоспалительным и обезболивающим действиями. Адотра гель обеспечивает сопротивление костей, ускоряет восстановление переломов.</p>\n\n<p><strong>Форма выпуска</strong>: 50 гр гель</p>', '', 'adorta-gel---17-1564581694.07-1564581694.19-1564581694.png', 0, 0, 0, 1),
(26, 9, 0, 1563017265, 'ADOSAL', 'ADOSAL', '', '', '', '', '', '', '', '<p><strong>ADOSAL</strong> consists of complex ingredients with a sedative, neuroprotective, antidepressant action. It is used to treat disorders of the central nervous system, encephalopathy, sleep disorders, neurosis-like states, and tics observed in various mental disorders. It improves the central nervous system and peripheral circulation, prevents hypoxia. Improves mood by increasing serotonin levels. Prevents symptoms like neurosis, excitability and tearfulness.</p>\n\n<p><strong>Release form</strong>: №20 tablets</p>', '<p><strong>ADOSAL</strong> состоит из комплексных ингредиентов с седативным, нейропротекторным, антидепрессантным действием. Применяется для лечения расстройств центральной нервной системы, энцефалопатии, нарушений сна, неврозаподобгых состаяниях, тиков, наблюдаемых при различных психических расстройствах. Улучшает центральную нервную систему и периферическое кровообращение, предотвращает гипоксию. Улучшает настроение за счет повышения уровня серотонина. Предотвращает симптомы как неврозность, возбудительность и плаксивость.</p>\n\n<p><strong>Форма выпуска</strong>: №20 таблетки</p>', '', 'adosal---17-1564581645.07-1564581645.19-1564581645.png', 0, 0, 0, 1),
(27, '5-7-8-14', 0, 1563017471, 'ADOVİN', 'ADOVİN', '', '', '', '', '', '', '', '<p><strong>ADOVIN</strong> is rich in vitamins, minerals, trace elements and omega-3, necessary for the normal functioning of the body. It controls the intensity of the metabolic process, increases the body&single_quot;s resistance to adverse environmental factors and boosts immunity, improves eyesight and is recommended for the prevention of cardiovascular diseases, rheumatism and skin diseases, including rehabilitation.</p>\n\n<p><strong>Release form</strong>: №40 capsules</p>', '<p><strong>ADOVİN</strong> богат витаминами, минералами, микроэлементами и омега-3, необходимыми для нормального функционирования организма. Он контролирует интенсивность обменного процесса, повышает сопротивляемость организма к неблагоприятным факторам окружающей среды и повышает иммунитет, улучшает зрение и рекомендуется для профилактики сердечно-сосудистых заболеваний, ревматизма и кожных заболеваний, включая реабилитацию.</p>\n\n<p><strong>Форма выпуска</strong>: №40 капсулы</p>', '', 'adovin---17-1564581611.07-1564581611.19-1564581611.png', 0, 0, 0, 1),
(28, '14-19', 0, 1563018692, 'ADUROL', 'ADURAL', '', '', '', '', '', '', '', '<p><span title=""><strong>ADUROL</strong> has anti-inflammatory, uroseptic and urine-producing effects, restoring damaged mucous membranes of the urinary tract.</span> <span title="">Due to its diuretic effect, it allows microbes to be washed away from the urinary tract.</span> <span title="">During the destruction of bacteria in the urinary tract, the bacteria block the lectin layer, separating the mucous membranes with an anti-adhesion effect and removing them by urine.</span> <span title="">It increases the resistance of the organism to infections by stimulating the immune system, normalizing the pH of the urine by dividing free radicals by antioxidant effect.</span></p>\n\n<p><span title=""><strong>Release form</strong>: №30 capsules</span></p>', '<p><strong>ADUROL</strong> обладает противовоспалительным, уросептическим, мочегонным эффектами, восстанавливает поврежденную слизистую оболочку мочевыводящих путей. Благодаря мочегонному эффекту микробы вымываются из мочевыводящих путей. Устраняя бактерии из мочевых путей, блокируют слой лектина бактерий и удаляют их через мочу. Стимулирует иммунную систему для повышения устойчивости организма к инфекциям, обладает антиоксидантными свойствами, блокирует свободные радикалы, восстанавливает рН мочи.</p>\n\n<p><strong>Форма выпуска</strong>: №30 капсулы</p>', '', 'adurol---17-1564581572.07-1564581572.19-1564581572.png', 0, 0, 0, 1),
(29, '5-7-13', 0, 1563019130, 'ESDADA', 'ESDADA', '', '', '', '', '', '', '', '<p><strong>ESDADA</strong> is rich in vitamins, minerals, trace elements, carotenoids lutein, necessary for the normal functioning of the body. It controls the intensity of the metabolic process, activates the immune system, increases the body&single_quot;s resistance to adverse environmental factors, and the minerals contained in it provide acid-base regulators, water-salt metabolism. Restores the lost vitamin, mineral, antioxidant balance in chronic diseases, various diets.</p>\n\n<p><strong>Release form</strong>: №30 capsules</p>', '<p><strong>ESDADA</strong> богата витаминами, минералами, микроэлементами, каротиноидами лютеином, необходимыми для нормального функционирования организма. Он контролирует интенсивность обменного процесса, активизирует иммунную систему, повышает устойчивость организма к неблагоприятным факторам окружающей среды, а содержащиеся в нем минералы обеспечивают кислотно-щелочные регуляторы, водно-солевой обмен. Восстанавливает утраченный витаминный, минеральный, антиоксидантный баланс при хронических заболеваниях, различных диетах.</p>\n\n<p><strong>Форма выпуска</strong>: №30 капсулы</p>', '', 'esdada---17-1564581530.07-1564581530.19-1564581530.png', 0, 0, 0, 1),
(30, '14-19', 0, 1563019396, 'FORTED', 'FORTED', '', '', '', '', '', '', '', '<p><strong>FORTED</strong> combined urological agent with uroseptic, diuretic, litholytic, lithokinetic and nephroprotective action. Thanks to natural ingredients it has a strong bactericidal effect. As a result of the diuretic effect, it accelerates the removal of bacteria and clears urinary tract infections. Due to the content of potassium citrate, it peaches urine and helps remove oxalate stones.</p>\n\n<p><strong>Release form</strong>: №30 tablets</p>', '<p><strong>FORTED</strong> комбинированное урологическое средство с уросептическим, мочегонным, литолитическим, литокинетическим и нефропротекторным действием. Благодаря натуральным ингредиентам обладает сильным бактерицидным эффектом. В результате мочегонного эффекта, он ускоряет удаление бактерий и очищает от инфекций мочевыводящих путей,Благодаря содержанию цитрата калия он ошелачивает мочу и способствует удалению оксалатных камней,</p>\n\n<p><strong>Форма выпуска</strong>: №30 таблетки</p>', '', 'forted---17-1564581496.07-1564581496.19-1564581496.png', 0, 0, 0, 1),
(31, '9-10', 0, 1563019845, 'NEUROAD', 'NEUROAD', '', '', '', '', '', '', '', '<p><span title=""><strong>NEUROAD</strong> has a combined sedative, neuroprotective, antispasmodic effect, regulates the function of the central nervous system.</span> <span title="">Normalizes the process of awakening when braking.</span> <span title="">Improves central and peripheral circulation.</span> <span title="">Reduces the risk of dizziness, relieves hypertension, causing vascular and diuretic effects.</span> <span title="">Reduces gastrointestinal spasm.</span></p>\n\n<p><span title=""><strong>Release form</strong>: 30 ml drops</span></p>', '<p><strong>NEUROPAD</strong> обладает комбинированным седативным, нейропротекторным, спазмолитическим действием, регулирует функцию центральной нервной системы. Нормализует процессы пробуждения при торможении. Улучшает центральное и периферическое кровообращение. Снижает риск головокружения, снимает гипертонию, вызывая сосудистые и мочегонные действия. Уменьшает спазм желудочно-кишечного тракта.</p>\n\n<p><strong>Форма выпуска</strong>: 30 мл капли</p>', '', 'neuroad---17-1564581465.07-1564581465.19-1564581465.png', 0, 0, 0, 1),
(32, '3-5', 0, 1563020278, 'OSTEAD', 'OSTEAD', '', '', '', '', '', '', '', '<p><strong>OSTEAD</strong> is designed to fully form and protect bone mass. It is important for the normal functioning of many enzymatic processes, muscles, bones and the nervous system due to its minerals. In particular, Chromium improves the level of dehydroepiandrosterone and is involved in the treatment of osteoporosis, it is also boron for regulating parathyroid hormone responsible for the exchange of calcium, phosphorus, magnesium and vitamin D.<br />Ostead also strengthens tendons, provides normal protein synthesis and collagen formation.</p>\n\n<p><strong>Release form</strong>: №30 tablets</p>', '<p><strong>OSTEAD</strong> предназначен для полного формирования и защиты костной массы. Он важен для нормального функционирования многих ферментативных процессов, мышц, костей и нервной системы благодаря своим минералам. В частности, хрому улучшающий уровень дегидроэпиандростерона и участвующему в лечении остеопороза, он также бору для регулирования паратгормона отвечающий за обмен кальция, фосфора, магния и витамина D. <br />Оstead также укрепляет сухожилия, обеспечивает нормальный синтез белка и образование коллагена.</p>\n\n<p><strong>Форма выпуска</strong>: №30 таблетки</p>', '', 'ostead---17-1564581389.07-1564581389.19-1564581389.png', 0, 0, 0, 1),
(33, '14-15-17', 0, 1563020920, 'TAYT PLUS', 'TAYT PLUS', '', '', '', '', '', '', '', '<p>Thanks to the plants contained in <strong>TAYT PLUS,</strong> it provides antiseptic, anti-edema, wound healing and antimicrobial effect in the vaginal area. Antimicrobial, anti-fungal and anti-virus effect in the presence of many plants by increasing the synergism, allows high effects during the use of vaginal tightening effects were observed.</p>\n\n<p><strong>Release form</strong>: 50 ml gel</p>', '<p>Благодаря растениям входящие в состав <strong>TAYT PLUS</strong> оказывает местное противоспалительное, противотековое, улучшающий регенерацию, антисептическое и противомикробное действие во влагалище. Наличие в составе одномоментно нескольких растений обладающие антибактериальным, противогрибковым, противовирусным действиями позволяет получить высокий синергистический эффект При применении наблюдается также сужение влагалища.</p>\n\n<p><strong>Форма выпуска</strong>: 50 мл гель</p>', '', 'tayt-plus---17-1564581280.07-1564581280.19-1564581280.png', 0, 0, 0, 1),
(35, '14-17', 0, 1563782753, 'TAYT VAG', 'TAYT VAG', '', '', '', '', '', '', '', '<p><strong>TAYT VAG </strong>is a disposable shower for vaginal and external genital hygiene. Due to its unique composition, it has antiseptic, anti-inflammatory, antifungal effects and improves vaginal microflora. Tayt vag reduces burning sensation, itching and unpleasant smell. With regular use, it cleans the vagina from the secretions and restores vaginal microbiocenosis. It is ideally combined with other devices (candles, spirals, gels, etc.).</p>\n\n<p><strong>Release form</strong>: 5 vials</p>', '<p><strong>TAYT VAG </strong>одноразовый душ для гигиены влагалища и наружных половых органов. Благодаря уникальному составу обладает антисептическим, противовоспалительным, противогрибковым и улучшающим микрофлору влагалища действиями. Тайт ваг уменьшает чувства жжения, зуда и неприятный запах. При регулярном применение очищает влагалище от выделений и восстанавливает микробиоциноз вагины. Идеально сочетается с другими средствами (свечи, спирали, гели и т.д).</p>\n\n<p><span><strong>Форма выпуска</strong>: 5 </span>флаконы</p>', '', 'tayt-vag-5-1563782888.png', 0, 0, 0, 1),
(36, '6-10', 0, 1565091850, 'TION 3', 'TİON 3', '', '', '', '', '', '', '', '<p><strong>TION 3 </strong> is using as a medical device in nasal cavity sanitation. The use of nasal aspirator is recommended for the baby to breathe comfortably before going to bed, especially with the time interval you consume before eating. <strong>Tion 3</strong> nasal aspirator is designed to conveniently remove nasal excretion from the nose. <span title="">Tion 3 is present in the filter that makes the nasal aspirator hygienic.</span> <span title="">Thanks to the ultra-soft tip, Tion 3 nasal aspirator cleans the baby&single_quot;s nose without causing it.The specificity of the Tion 3 aspirant is that it has three additional ends with the aspirator.These disposable tips are available as a 3-pack.The removal of the mucus from nose also helps prevent some complications. Tion 3 nasal aspirator is used after physiological, hypertonic, or ocean water (Oretal) solutions. These solutions facilitate the removal of nasal secretions from the baby&single_quot;s nose. It should be used under control on newborns. For hygienic reasons, aspirator&single_quot;s tips are single-use.</span></p>\n\n<p><span title=""><br /></span></p>\n\n<p><strong>Release form</strong>: Nasal aspirator with 3 soft tips</p>', '<p>Используется в качестве медицинского оборудования для санации полости носаспользование аспиратора для носа рекомендуется в течение промежутка времени, который вы считаете подходящим перед едой, особенно перед сном, чтобы ребенок мог дышать с комфортом. Носовой аспиратор <strong>TİON 3</strong> предназначен для легкого очищения носа от носа. Носовой аспиратор TİON 3 имеет гигиенический фильтр. Благодаря ультрамягким насадкам, назальный аспиратор TİON 3 очищает нос ребенка. Особенность аспиратора TİON 3 состоит в том, что у аспиратора есть три дополнительных конца. Эти одинарные концы доступны в виде 3-х упаковок. Получение носового прохода из носа также помогает предотвратить некоторые осложнения. Носовой аспиратор TİON 3 используется после физиологических, гипертонических или океанических водных растворов (Oretal). Эти решения позволяют легко удалить носовой ход из носа ребенка. Гигиенически, советы аспиратора были использованы в одиночку.</p>\n\n<p>&nbsp;</p>\n\n<p><strong>Форма выпуска</strong>: Носовой аспиратор с 3 мягкими наконечниками</p>', '', 'tion-3-1565091923.png', 0, 0, 0, 1),
(39, 6, 0, 1565186760, 'ESOL', 'ESOL', '', '', '', '', '', '', '', '<p><strong>ESOL</strong> is a composition that maintains a normal balance between the nasal cavity and sinuses. ESOL cleanses the nasal cavity from mucus. Washing the nose with Esol&nbsp; is an effective treatment and prevention of the development of acute respiratory diseases. Esol is effective for washing the nose at home for both adults and children at any age, it is allowed during pregnancy. Eliminates edema, hyperemia of the nasal cavity, improves nasal breathing. Its also developed for nasal hygiene.</p>\n\n<p><strong>Release form</strong>: 20 pcs solution mix packages</p>', '<p><strong>ESOL</strong> - это состав, поддерживающий нормальный пн баланс&nbsp; полости носа и пазух. ESOL очищает носовую полость от слизи. Промывание носа Esol содержающим раствором, является эффективным лечением и профилактикой развития острых респираторных заболеваний. Esol эффективен для промывания носа в домашних условиях и для взрослых, и для детей в любом возрасте, разрешен во время беременности. Устраняет отек, гиперемию носовой полости, улучшает носовой дыхание. Также предназначен для гигиены носовой полости.</p>\n\n<p><strong>Форма выпуска</strong>: пакеты для приготовления раствора по 20 штук</p>', '', 'esol-1565186828.png', 0, 0, 0, 1),
(37, 6, 0, 1565098613, 'VELORAL', 'VELORAL', '', '', '', '', '', '', '', '<p><strong>VELORAL</strong> is using for nasal and sinus cavity cleaning as a medical remedy.<br />How to use:<br />Step 1: Open the bottle of Veloral 240 ml and add water (warmish or room temperature) to the specified point.<br />Step 2: Add the powder from the Veloral pack to the bottle filled with water. A package should be added to 240 ml of water. Close the lid cover firmly. Hold the hole in the cover with your hand.<br />Step 3: Bring your head straight to the front, keep your mouth open, and then maximize the hole in the lid cover to your nose.<br />Step 4: Hand-squeeze the plastic vial. You will then see the flow of water through the other nostrils. You can perform this procedure several times in your nostril. You can exhale and hold while performing the operation. To complete the process, &frac14; or &frac12; of the vial should be emptied.<br />Step 5: Steps 3 and 4 should be applied to the other nostrils.<br />Step 6: After the procedure is completed, quickly exhale the residual waste in the nasal cavity and do not reuse the residual solution in the vial. The procedure should be done once a day.</p>\n\n<p>&nbsp;</p>\n\n<p><strong>Release form</strong>: 5 packets +240 ml vial</p>', '<p><strong>VELORAL</strong> используется для очистки полости носа и пазухи в качестве лечебного средства.<br />Как пользоваться:<br />Шаг 1: Откройте флакон Veloral на 240 мл и добавьте воду (теплой или комнатной температуры) до указанной точки.<br />Шаг 2: Добавьте порошок из пакета Veloral в бутылку с водой. В пакет следует добавить до 240 мл воды. Плотно закройте крышку. Держите отверстие в крышке рукой.<br />Шаг 3: Подведите голову прямо вперед, держите рот открытым, а затем увеличьте отверстие в крышке до носа.<br />Шаг 4: Сожмите вручную пластиковый флакон. Затем вы увидите поток воды через другие ноздри. Вы можете выполнить эту процедуру несколько раз в ноздрю. Вы можете выдохнуть и удерживать во время выполнения операции. Для завершения процесса, &frac14; или &frac12; флакона должны быть опорожнены.<br />Шаг 5: Шаги 3 и 4 должны быть применены к другим ноздрям.<br />Шаг 6: После завершения процедуры быстро выдохните остаточные отходы в полости носа и не используйте повторно остаточный раствор во флаконе. Процедура должна проводиться один раз в день.</p>\n\n<p>&nbsp;</p>\n\n<p><strong>Форма выпуска</strong>: 5 пакетиков + 240 мл флакон</p>', '', 'veloral-1565098593.png', 0, 0, 0, 1),
(38, '6-10', 0, 1565167465, 'VELORAL KIDS', 'VELORAL KIDS', '', '', '', '', '', '', '', '<p><strong>VELORAL KIDS</strong> is using for nasal and sinus cavity cleaning as a medical remedy.<br />How to use:<br />Step 1: Open the bottle of Veloral 120 ml and add water (warmish or room temperature) to the specified point.<br />Step 2: Add the powder from the Veloral kids pack to the bottle filled with water. A package should be added to 120 ml of water. Close the lid cover firmly. Hold the hole in the cover with your hand.<br />Step 3: Bring your head straight to the front, keep your mouth open, and then maximize the hole in the lid cover to your nose.<br />Step 4: Hand-squeeze the plastic vial. You will then see the flow of water through the other nostrils. You can perform this procedure several times in your nostril. You can exhale and hold while performing the operation. To complete the process, &frac14; or &frac12; of the vial should be emptied.<br />Step 5: Steps 3 and 4 should be applied to the other nostrils.<br />Step 6: After the procedure is completed, quickly exhale the residual waste in the nasal cavity and do not reuse the residual solution in the vial. The procedure should be done once a day.</p>\n\n<p>&nbsp;</p>\n\n<p><strong>Release form</strong>: 5 packets +120 ml vial</p>', '<p><strong>VELORAL KIDS</strong> используется для очистки полости носа и пазухи в качестве лечебного средства.<br />Как пользоваться:<br />Шаг 1: Откройте флакон Veloral kids на 120 мл и добавьте воду (теплой или комнатной температуры) до указанной точки.<br />Шаг 2: Добавьте порошок из пакета Veloral в бутылку с водой. В пакет следует добавить до 120 мл воды. Плотно закройте крышку. Держите отверстие в крышке рукой.<br />Шаг 3: Подведите голову прямо вперед, держите рот открытым, а затем увеличьте отверстие в крышке до носа.<br />Шаг 4: Сожмите вручную пластиковый флакон. Затем вы увидите поток воды через другие ноздри. Вы можете выполнить эту процедуру несколько раз в ноздрю. Вы можете выдохнуть и удерживать во время выполнения операции. Для завершения процесса, &frac14; или &frac12; флакона должны быть опорожнены.<br />Шаг 5: Шаги 3 и 4 должны быть применены к другим ноздрям.<br />Шаг 6: После завершения процедуры быстро выдохните остаточные отходы в полости носа и не используйте повторно остаточный раствор во флаконе. Процедура должна проводиться один раз в день.</p>\n\n<p>&nbsp;</p>\n\n<p><strong>Форма выпуска</strong>: 5 пакетиков + 120 мл флакон</p>', '', 'veloral-kids-1565168038.png', 0, 0, 0, 1),
(40, '6-10', 0, 1565264412, 'ESOL KIDS', 'ESOL KIDS', '', '', '', '', '', '', '', '<p><strong>ESOL KIDS&nbsp;</strong>is a composition that maintains a normal balance between the nasal cavity and sinuses. Esol kids cleanses the nasal cavity from mucus. Washing the nose with Esol kids is an effective treatment and prevention of the development of acute respiratory diseases. Esol kids is effective for washing the nose at home for both adults and children at any age, it is allowed during pregnancy. Eliminates edema, hyperemia of the nasal cavity, improves nasal breathing. Its also developed for nasal hygiene.</p>\n\n<p><strong>Release form</strong>: 20 pcs solution mix packages</p>', '<p><strong>ESOL&nbsp;</strong>- это состав, поддерживающий нормальный пн баланс полости носа и пазух. Esol kids очищает носовую полость от слизи. Промывание носа Esol kids содержающим раствором, является эффективным лечением и профилактикой развития острых респираторных заболеваний. Esol kids эффективен для промывания носа в домашних условиях и для взрослых, и для детей в любом возрасте, разрешен во время беременности. Устраняет отек, гиперемию носовой полости, улучшает носовой дыхание. Также предназначен для гигиены носовой полости.</p>\n\n<p><strong>Форма выпуска</strong>: пакеты для приготовления раствора по 20 штук</p>', '', 'esol-kids-1565265552.png', 0, 0, 0, 1),
(41, 6, 0, 1565265818, 'ORETAL', 'ORETAL', '', '', '', '', '', '', '', '<p><strong>ORETAL</strong> -&nbsp;is an ocean water for nose cleaning. Ocean water is a natural remedy for the prevention and treatment of rhinitis. It is rich in minerals, moisturizes the nasal mucosa, accelerates the recovery process, helps eliminate swelling and inflammation, and improves the function of small capillaries. It also has antiseptic properties.</p>\n\n<p><strong>Release form</strong>:&nbsp;5ml x 10 pcs one dose vials</p>', '<p><strong>ORETAL</strong> - это oкеаническая вода для чистки носа. Океаническая вода является естественным средством для профилактики и лечения насморка. Он богат минералами, увлажняет слизистую оболочку носа, ускоряет процесс выздоровления, помогает устранить отеки и воспаления, а также улучшает функцию мелких капилляров. Он также обладает антисептическими свойствами.</p>\n\n<p><strong>Форма выпуска</strong>: 5 мл х 10 флаконов по одной дозе</p>', '', 'oretal-1565267138.png', 0, 0, 0, 1),
(42, 3, 0, 1565269799, 'ADEKSOL', 'ADEKSOL', '', '', '', '', '', '', '', '<p><strong>Aerosol foam ADEKSOL</strong> has anti-inflammatory effect, improves microcirculation, has local anesthetic and analgesic effects. It is easy to use, it is absorbed immediately and does not leave a mark and oil. Adeksol helps fight arthritis, arthrosis and rheumatism, relieves pain during inflammation of joints, muscles, restores mobility after trauma, skin and tissue regeneration, stimulates blood supply,relieves muscle tension in sedentary lifestyles.</p>\n\n<p><strong>Release form</strong>: 150 ml aerosol foam</p>', '<p><strong>Аэрозольная пена&nbsp;ADEKSOL</strong>&nbsp;обладает противовоспалительным эффектом, улучшает микроциркуляцию, оказывает местное анестезирующее и обезболивающее действие. Благодаря пенистой форме&nbsp;Адексол помогает бороться с артритом, артрозом и ревматизмом, снимает боль при воспалениях суставов, мышц, восстанавливает подвижность после травм, регенерацию кожи и тканей, стимулирует кровоснабжение, снимает мышечное напряжение при малоподвижном образе жизни.</p>\n\n<p><strong>Форма выпуск</strong>а: 150 мл аэрозольной пены</p>', '', 'adeksol-aerosol-foam-150-ml-700x700-1565271059.png', 0, 0, 0, 1),
(43, 11, 0, 1566812529, 'APLECON', 'APLECON', '', '', '', '', '', '', '', '<p><strong>APLECON</strong> is a gentle cream for nipples. It moisturizes and soothes sensitive nipples especially for pregnant and lactating women. It is advisable to use after each shower to reduce tension during pregnancy. The cream is soothing, softening, antiseptic, enhancing the elasticity and healing properties of olive oil and lanol. Free of flavor, odorless &amp; colorless safe for both baby and mother. During breastfeeding, the cream should be used after cleansing the breast with mother milk.</p>\n\n<p><strong>Release form</strong>: 30 gr cream</p>', '<p><strong>APLECON</strong> - это нежный крем для сосков. Увлажняет и успокаивает чувствительные соски, особенно для беременных и кормящих женщин. Рекомендуется использовать после каждого душа, чтобы уменьшить напряжение во время беременности. Крем успокаивающий, смягчающий, антисептический, усиливающий эластичность и целебные свойства оливкового масла и ланола. Без аромата, без запаха и цвета безопасен для малыша и матери. Во время грудного вскармливания крем следует использовать после очищения груди с помощью материнского молока.</p>\n\n<p><strong>Форма выпуска</strong>: 30 г крема</p>', '', 'aplecon-1566812541.jpg', 0, 0, 0, 1),
(44, 14, 0, 1566818520, 'AUR FEMIGAR', 'AUR FEMIGAR', '', '', '', '', '', '', '', '<p><strong>AUR FEMIGAR</strong> disposable combination vaginal shower is designed for personal hygiene. It has antiseptic, anti-inflammatory, decongestant, antifungal, wound healing effects. The solution contains 1.25% acetic acid, which can adjust the pH of the vagina from 3 to 5. Thanks to the appropriate pH and acetic acid, it helps to treat &ldquo;bacterial vaginitis&rdquo; and &ldquo;cervical erosion&rdquo;. During bacterial vaginitis, conditionally pathogenic microflora turns into pathogenic. It contains tea tree oil, which acts as an antiseptic against pathogenic bacteria. Aur femigar contains Aloe Vera to reduce burning and itching.</p>\n\n<p><strong>Release form</strong>: 100 ml disposable vaginal douche</p>', '<p><strong>AUR FEMIGAR </strong>- Одноразовый комбинированный вагинальный душ Aur Femigar предназначен для личной гигиены. Обладает антисептическим, противовоспалительным, противоотечным, антифунгальным, ранозаживляющим действиями. Раствор содержит 1,25% уксусную кислоту, которая может регулировать рН влагалища от 3 до 5. Благодаря соответствующему pH и уксусной кислоте, помогает лечить &laquo;бактериальный вагинит&raquo; и &laquo;эрозию шейки матки&raquo;. Во время бактериального вагинита условно-патогенная микрофлора превращается в патогенную. В составе имеется масло чайного дерева, который действует как антисептик против патогенных бактерий. Aur Femigar содержит Алоэ Веру для уменьшения жжения и зуда.</p>\n\n<p><strong>Форма выпуска</strong>: 100 мл одноразовый вагинальный душ</p>', '', 'aur-femigar-1566818557.jpg', 0, 0, 0, 1),
(45, 14, 0, 1566819136, 'AUR FOAM', 'AUR FOAM', '', '', '', '', '', '', '', '<p><strong>AUR FOAM - </strong>daily cleansing of the genitalia with a soap can cause dysbiosis. For these purposes, we offer intimate Aurfoam soap. It has is an antiseptic product specially designed for soft cleansing of external genitalia. Its active ingredient is Hexamidine Dezetionate, which is very effective against bacteria, fungi and unpleasant odors. The soft consistency and specially selected formulation correspond to the natural structure of the pH of the genital organs and do not cause dysbiosis when purified. Gives freshness, cleanliness and comfort when used throughout the day. Suitable for frequent and long-term use.</p>\n\n<p><strong>Release form</strong> : 200 ml foam</p>', '<p><strong>AUR FOAM</strong> - Ежедневная очистка обычным мылом наружных половых органов приводит к дизбактериозу. Для таких целей предлагаем пену Аур фоам для гениталий . Это антисептический продукт, специально разработанный для бережной очистки наружных половых органов. Её активным компотентом является Гексамидин Дезетионат очень эффективен против бактерий, грибков и неприятных запахов. Мягкая консистенция и специально подобранная формула совместима с естественной структурой pH в области гениталий, при очистке которой не вызывает дисбиоз. При использовании в течение дня поддерживает свежесть, ощущение чистоты и комфорт. Подходит для частого и длительного использования.</p>\n\n<p><strong>Форма выпуска</strong>: 200 мл пены</p>', '', 'aurfoam-1566820372.jpg', 0, 0, 0, 1),
(46, 14, 0, 1566820475, 'AUR LACT', 'AUR LACT', '', '', '', '', '', '', '', '<p><strong>AUR LACT</strong> is daily cream for the genital area, it has delicate and soft consistency with a special formula, rich in aloe vera extract, tea tree oil and lactic acid. Lactic acid restores the vaginal microflora and supports its pH in the range from 3.8 to 4.5. Tea tree oil has an antiseptic effect and reduces irritation and burning caused by itching and dryness in the genital area. Aloe vera has anti-inflammatory and antiseptic effects. Thanks to this composition, it is used to protection of external genital area.</p>\n\n<p><strong>Release form</strong>: 100 ml vaginal cream</p>', '<p><strong>AUR LACT</strong> ето ежедневный крем для генитальной области, крем нежной и мягкой консистенции с особой формулой, богатый экстрактом алоэ веры, маслом чайного дерева и молочной кислотой. Молочная кислота восстанавливает микрофлору влагалища и поддерживает ее Рн в пределах от 3,8 до 4,5. Масло чайного дерева обладает антисептическим эффектом и уменьшает раздражение и жжение, вызванные зудом и сухостью в области половых органов. Алоэ вера обладает противовоспалительным и антисептическим действиями. Благодаря такому составу используется для защиты области наружных половых</p>\n\n<p><strong>Форма выпуск</strong><span><strong>а</strong>: 100 мл вагинальный крем</span></p>', '', 'aurlact-1566821448.jpg', 0, 0, 0, 1),
(47, 14, 0, 1566821575, 'AUR SEDA', 'AUR SEDA', '', '', '', '', '', '', '', '<p><strong>AUR SEDA</strong> is a genital cleansing soap. It contains sodium bicarbonate, which has a thinning effect. If a woman has thick discharge, it is ideal for them. Aur Seda was developed by specialists for cleaning the female genital organs from fungal and bacterial vaginitis. Aur Seda protects the genitals from germs causing inflammatory processes.</p>\n\n<p><strong>Release form</strong>: 100 ml disposable vaginal douche</p>', '<p><strong>AUR SEDA</strong> это очищающее мыло для половых органов. Он в составе имеет натрий бикарбонат, обладающий разжижающим действием. Если у женщины имеются густые выделения, он им идеально подходит. Aur seda разработана специалистами для чистки женских половых органов при грибковом и бактериальном вагините. Aur seda защищает половые органы от микробов вызывающие воспалительные процессы.</p>\n\n<p><strong>Форма выпуск</strong><span><strong>а</strong>: 100 мл одноразовый вагинальный душ</span></p>', '', 'aur-sedaa-1566822186.jpg', 0, 0, 0, 1),
(48, 14, 0, 1566822283, 'AUR TİGHT', 'AUR TİGHT', '', '', '', '', '', '', '', '<p><strong>AUR TİGHT</strong> is a disposable vaginal shower with antiseptic, disinfectant, bactericidal action. With regular use, it reduces the vaginal lumen, because potassium sulfate is present in the composition. It contains a component called aluminum sulfate, which helps women with enuresis (urinary incontinence) after multiple births. It also contains potassium sulfate, with regular use of which improves sexual quality and orgasm. It has a bactericidal and disinfecting effect due to the content of benzalkonium chloride in the composition. Benzalkonium chloride also has antifungal (Candida albicans), antiprotozoal (Chlamydia, Trichomonas vaginalis) and local contraceptive (spermatocidal) actions; inactivates viruses that cause Herpes Simplex. This shower protects a woman from sexually transmitted diseases.</p>\n\n<p><strong>Release form</strong>: 100 ml disposable vaginal douche</p>', '<p><strong>AUR TİGHT - </strong>Это одноразовый душ для влагалища, обладающий антисептическим, дезинфицирующим, бактерицидным действиями. При регулярном использовании уменьшает просвет влагалища, потому что в составе имеется сульфат калия. В составе есть компонент под названием сульфат алюминия, который помогает женщинам страдающим энурезом (недержанием мочи) после многоплодных родов. Также содержит сульфат калия, при регулярном использовании которого улучщается сексуальное качество и оргазм. Бактерицидное и дезинфицирующее действие оказывает из-за содержания в составе бензалкония хлорида. Бензалконий хлорид обладает также противогрибковым (Candida albicans), антипротозойным (Chlamydia ,Trichomonas vaginalis) и местное контрацептивным (сперматоцидное) действиями; инактивирует вирусы, вызывающие простой герпес (Herpes simplex). Этот душ защищает женщину от венерических болезней.</p>\n\n<p><strong>Форма выпуска</strong>: 100 мл одноразовый вагинальный душ</p>', '', 'aurtight-1566824104.jpg', 0, 0, 0, 1),
(56, 10, 0, 1567691772, 'BABY MERRY', 'BABY MERRY', '', '', '', '', '', '', '', '<p><strong>BABY MERRY</strong> is a product containing a combination of trace elements in the form of sodium and potassium chloride, trisodium citrate. Baby Merry has a detoxifying, restoring acid-base balance, disturbed due to the loss of electrolytes during vomiting, diarrhea, poisoning, and excessive sweating. Due to its unique composition, metabolic acidosis is correcting.</p>\n\n<p><strong>Release form</strong>: 150 ml oral solution</p>', '<p><strong>BABY MERRY</strong> это средство содержащее комбинацию микроэлементов в виде натрий и калий хлорида, тринатрий цитрата. Baby Merry обладает детоксикационным, восстановливающим кислотно-щелочную равновесию, нарушенная, вследствие потери электролитов при рвоте, диарее, отравлениях, обильном потоотделении. Из-за содержания уникального состава способствует коррекцию метаболического ацидоза.</p>\n\n<p><strong>Форма выпуска</strong>: 150 мл пероральный раствор</p>', '', 'baby-merry-1567692192.jpg', 0, 0, 0, 1),
(49, 14, 0, 1566824122, 'AUR VİRA', 'AUR VİRA', '', '', '', '', '', '', '', '<p><strong>AUR VIRA - </strong>daily genital Cleansing soap gently cleanses the external genital area while moisturizing. It is effective against bad odors caused by bacteria. Specially developed formula with rose extract for a long time leaves a feeling of freshness, does not dry the delicate skin of the genitals. The soap is designed for daily hygiene of the intimate area, and therefore compatible with the natural pH in the genital area.</p>\n\n<p><strong>Release form</strong>: 125 gr of a cleaning soap</p>', '<p>Ежедневное очищающее мыло <strong>AUR VİRA</strong> для гениталий деликатно очищает внешнюю область гениталий, одновременно увлажняя. Это эффективно против неприятных запахов, вызванных бактериями. Специально разработанная формула с экстрактом розы длительное время оставляет ощущения свежести, не сушит нежную кожу гениталий. Мыло расчитано для ежедневной гигиены интимной зоны, и поэтому совместима с естественной pH в области гениталий.</p>\n\n<p><strong>Форма выпуска</strong>: 125 гр чистящего мыла</p>', '', 'aurvira-1566824616.jpg', 0, 0, 0, 1),
(50, 11, 0, 1566824655, 'BELOVIN', 'BELOVIN', '', '', '', '', '', '', '', '<p><strong>BELOVIN</strong> is a firming cream against stretch marks. When used regularly, it helps to reduce the appearance of cracks in the skin and helps prevent the appearance of new stretch marks. Effective for cracks caused by pregnancy and weight gain. Belovine contains special oils such as almond oil, olive oil extracts and aloe vera to keep your skin soft and supple. These oils contain a lot of linoleic and oleic acids, vitamins A, F, E and B2, magnesium, phosphorus, zinc, carotenes and many other useful substances that nourish and strengthen the skin.</p>\n\n<p><strong>Release form</strong>: 30 gr cream</p>', '<p><strong>BELOVIN</strong> это укрепляющий крем против растяжек . При регулярном использовании помогает уменьшить появление трещин на коже и помогает предотвратить появление новых растяжек. Эффективен при трещинах, вызванных беременностью и увеличением веса. Беловин содержит специальные масла, такие как миндальное масло, экстракты оливкового масла и алоэ вера, чтобы сохранить кожу мягкой и эластичной. В составе этих масел содержится много линолевой и олеиновой кислот, витамины А, F,Е и В2, магний, фосфор, цинк, каротины и многие другие полезные вещества, питающие и укрепляющие кожу.</p>\n\n<p><strong>Форма выпуск</strong><span><strong>а</strong>: 30 г крем</span></p>', '', 'belovin-1566825367.jpg', 0, 0, 0, 1),
(51, 4, 0, 1566825394, 'ENOMOMAX', 'ENOMOMAX', '', '', '', '', '', '', '', '<p><strong>ENOMOMAX</strong> is a rectal device that has an irritating effect on the mucous membrane of the rectum and reflex stimulation of the intestinal motility, helping to exacerbate the mass of the stool instantly and without pain. Enomomax is used by men and women over 12 years of age and can be used twice a day if needed. It is not recommended to use more than seven days.</p>\n\n<p><strong>Release form</strong>: 6,75 gr glycerol rectal solution</p>', '<p><strong>ENOMOMAX</strong> - это слабительное средство, оказывающее легкое раздражающее воздействие на слизистую прямой кишки и рефлекторно стимулирующее двигательную активность кишечника, кроме этого, препарат смягчает каловые массы, что способствует их более быстрому и безболезненному выведению.<br />Enomomax используется мужчинами и женщинами старше 12 лет, при необходимости может применяться два раза в день. Использование клизмы более семи дней не рекомендуется.</p>\n\n<p><strong>Форма выпуска</strong>: 6,75 гр глицерина ректального раствора</p>', '', 'enomomax-1566826894.jpg', 0, 0, 0, 1),
(52, 14, 0, 1566826950, 'FEMIAUR', 'FEMIAUR', '', '', '', '', '', '', '', '<p><strong>FEMIAUR</strong> -Disposable vaginal douche has been specially designed for vaginal hygiene. It contains 10% povidone iodine as an active ingredient. It has antiseptic, antiviral and antibacterial properties. It is used for bacterial, chlamydial, ureaplasma and mycoplasma vaginitis. Femiaur, unlike other antiseptics, normalizes the acidity of the vaginal environment, which creates the conditions for the rapid restoration of the normal microflora of the vagina, which is an important factor in the absence of relapse of the vaginal infection after treatment. It has no side effects due to its active organic ingredients.</p>\n\n<p><strong>Release form</strong>: 5 ml x 10 ampoules</p>', '<p><strong>FEMIAUR </strong>-одноразовый вагинальный душ был специально разработан для гигиены влагалища. Он содержит 10% йода повидона в качестве активного ингредиента. Обладает антисептическими, противовирусными и антибактериальными свойствами. Применяется при бактериальной, хламидийной, уреаплазменной и микоплазменной вагинитах . Фемиаур в отличие от других антисептиков, нормализует кислотность вагинальной среды, чем создает условия для быстрого восстановления нормальной микрофлоры влагалища, что является важным фактором отсутствия рецидивов вагинальной инфекции после лечения. Он не проявляет побочных эффектов благодаря своим активным органическим ингредиентам.</p>\n\n<p><strong>Форма выпуска</strong>: 5 мл х 10 ампул</p>', '', 'femiaur-1566827951.jpg', 0, 0, 0, 1),
(53, 4, 0, 1566885560, 'RECTOMAX', 'RECTOMAX', '', '', '', '', '', '', '', '<p><strong>RECTOMAX</strong> is an enema for cleansing the intestines from feces. Rectal solution is suitable for adults and young people over 12 years old. Suitable for professional use before rectal surgery, after prolonged constipation, before colonoscopy, reduces rectal tension and soreness before surgery. Not applicable for daily use.</p>\n\n<p><strong>Release form</strong>: 118 ml laxative saline solution</p>', '<p><strong>RECTOMAX - </strong>это клизма для ичищения кишечника от каловых масс. Ректальный раствор подходит для взрослых и молодых людей старше 12 лет. Подходит для профессионального использования перед ректальными операциями, после длительного запора, перед колоноскопией, Уменьшает напряжение прямой кишки и болезненность перед операцией. Не применяется для ежедневного использования.</p>\n\n<p><strong>Форма выпуска</strong>: 118 мл слабительный солевой раствор</p>', '', 'rectomax-1566887518.jpg', 0, 0, 0, 1),
(54, 14, 0, 1566893274, 'AUR FRESH', 'AUR FRESH', '', '', '', '', '', '', '', '<p><strong>AUR FRESH</strong> intimate area daily cleanser has anti-inflammatory, antibacterial and antifungal, deodorizing effects. Aur Fresh provides hygiene of the external genital organs, refreshes and gives comfort throughout the day. With the help of chamomile extract Aur Fresh gently cleanses and moisturizes, reduces inflammation in the external genital area. Its special formula, adjusted to pH 4.5, is compatible with the natural structure of the pH of the genital area. The sensation of freshness, which begins immediately, continues throughout the day.</p>\n\n<p><strong>Release form</strong>: 275 ml daily cleaning liquid</p>', '<p>Ежедневное очищающее средством <strong>AUR FRESH</strong>&nbsp;для интимной зоны обладает противовоспалительным, антибактериальным и противогрибковым, дезодорирующими действиями. Aur Fresh обеспечивает гигиену наружных половых органов, освежает и дарит комфорт в течение дня. С помощью экстракта ромашки Aur Fresh мягко очищает и увлажняет , уменьшает воспаление в областе наружных половых органов. Его специальная формула, настроенная на pH 4,5, совместима с естественной структурой pH области гениталий. Ощущение свежести, которое начинается сразу же, продолжается в течение дня.</p>\n\n<p><strong>Форма выпуска</strong>: 275 мл ежедневной чистящей жидкости</p>', '', 'aur-freshshhsh-1566893934.jpg', 0, 0, 0, 1),
(55, 14, 0, 1566969766, 'AUR SOD', 'AUR SOD', '', '', '', '', '', '', '', '<p><strong>AUR SOD</strong> is a disposable vaginal shower with 0.025% carbonate and 2% sodium bicarbonate which can adjust the pH of the solution between 8-9. This helps in relieving symptoms of vulvar vaginitis. Usually, women suffer from symptoms of vulvovaginitis during menopause. Aur sod is widely used by both women of childbearing and women during menopause. Thanks to the alkaline solution, the shower reduces burning and dryness in the vagina. It has antiseptic, antiviral and antibacterial properties. Contains aloe vera which helps reduce burning sensation and itching.</p>\n\n<p><strong>Release form</strong>: 100 ml of vaginal soap</p>', '<p><strong>AUR SOD</strong>&nbsp;это одноразовый вагинальный душ с 0,025% -ым карбонатом и 2%-ым бикарбонат натрия&nbsp; которые могут регулировать рН раствора между 8-9. Это помогает в облегчении симптомов при вульве-вагинитах. Обычно симптомами вульвовагинита страдают женщины во время менопаузы. Aur sod широко используется как женщинами детородного, так и женщинами во время менопаузы. Благодаря щелочному раствору, душ уменьшает жжение и сухость во влагалище. Он обладает антисептическими, противовирусными и антибактериальными свойствами. Содержит алоэ веру который помогает уменьшить жжение и зуд.</p>\n\n<p><strong>Форма выпуска</strong>: 100 мл вагинального мыла</p>', '', 'aursod-1566970486.jpg', 0, 0, 0, 1),
(57, 10, 0, 1567759595, 'BABY MİX 5 (Apple flavored)', 'BABY MİX 5 (Cо вкусом яблока)', '', '', '', '', '', '', '', '<p><strong>BABY MIX 5</strong> has a calming and polluting, antispasmodic effect thanks to its unique formula with natural active and effective ingredients. Baby Mix 5 also contains the active ingredient fennel, which has an antispasmodic effect on the smooth muscles of the intestines, which supports digestion, and is therefore widely used for spastic colic and digestive disorders.</p>\n\n<p><strong>Release form</strong>: 150 ml syrup</p>', '<p><strong>BABY MIX</strong> <strong>5</strong> благодаря уникальной формуле с натуральными активными и эффективными ингредиентами, обладает успокоивающим и ветрогонным, спазмолитическими действиями. Baby Mix 5 содержит активный компонент фенхель, который также способствует перевариванию, обладая спазмолитическим действием, особенно в отношении гладкой мускулатуры кишечника и поэтому широко применяется при спастических коликах и при расстройствах пищеварения.</p>\n\n<p><strong>Форма выпуска</strong>: 150 мл сироп</p>', '', 'baby-mix-5-apple-1567759578.jpg', 0, 0, 0, 1),
(58, 10, 0, 1567769483, 'BABY MIX 5 (Strawberry flavoured)', 'BABY MİX 5  (Со вкусом клубники)', '', '', '', '', '', '', '', '<p><strong>BABY MIX</strong><span> has a calming and polluting, antispasmodic effect thanks to its unique formula with natural active and effective ingredients. Baby Mix also contains the active ingredient fennel, which has an antispasmodic effect on the smooth muscles of the intestines, which supports digestion, and is therefore widely used for spastic colic and digestive disorders.</span></p>\n\n<p><span><strong>Release form</strong><span>: 150 ml syrup</span></span></p>', '<p><strong>BABY MIX </strong>благодаря уникальной формуле с натуральными активными и эффективными ингредиентами, обладает успокоивающим и ветрогонным, спазмолитическими действиями. Baby Mix содержит активный компонент фенхель, который также способствует перевариванию, обладая спазмолитическим действием, особенно в отношении гладкой мускулатуры кишечника и поэтому широко применяется при спастических коликах и при расстройствах пищеварения.</p>\n\n<p><strong>Форма выпуска:</strong> 150 мл сироп</p>', '', 'baby-mix-5-strawberry-1567769920.jpg', 0, 0, 0, 1),
(59, 10, 0, 1567770429, 'BABY MIX 5  (Banana flavoured)', 'BABY MIX 5 (Банановый ароматизированный)', '', '', '', '', '', '', '', '<p><strong>BABY MIX 5&nbsp;</strong>has a calming and polluting, antispasmodic effect thanks to its unique formula with natural active and effective ingredients. Baby Mix 5 also contains the active ingredient fennel, which has an antispasmodic effect on the smooth muscles of the intestines, which supports digestion, and is therefore widely used for spastic colic and digestive disorders.</p>\n\n<p><strong>Release form</strong>: 150 ml syrup</p>', '<p><strong>BABY MIX&nbsp;5</strong>&nbsp;благодаря уникальной формуле с натуральными активными и эффективными ингредиентами, обладает успокоивающим и ветрогонным, спазмолитическими действиями. Baby Mix 5 содержит активный компонент фенхель, который также способствует перевариванию, обладая спазмолитическим действием, особенно в отношении гладкой мускулатуры кишечника и поэтому широко применяется при спастических коликах и при расстройствах пищеварения.</p>\n\n<p><strong>Форма выпуска</strong>: 150 мл сироп</p>', '', 'baby-mix-5-banana-1567770728.jpg', 0, 0, 0, 1),
(60, 10, 0, 1567770787, 'BABY MİX 5 (Pineapple flavoured)', 'BABY MİX 5 (Со вкусом ананас)', '', '', '', '', '', '', '', '<p><strong>BABY MIX 5&nbsp;</strong>has a calming and polluting, antispasmodic effect thanks to its unique formula with natural active and effective ingredients. Baby Mix 5 also contains the active ingredient fennel, which has an antispasmodic effect on the smooth muscles of the intestines, which supports digestion, and is therefore widely used for spastic colic and digestive disorders.</p>\n\n<p><strong>Release form</strong>: 150 ml syrup</p>', '<p><strong>BABY MIX&nbsp;5&nbsp;</strong>благодаря уникальной формуле с натуральными активными и эффективными ингредиентами, обладает успокоивающим и ветрогонным, спазмолитическими действиями. Baby Mix 5 содержит активный компонент фенхель, который также способствует перевариванию, обладая спазмолитическим действием, особенно в отношении гладкой мускулатуры кишечника и поэтому широко применяется при спастических коликах и при расстройствах пищеварения.</p>\n\n<p><strong>Форма выпуска</strong>: 150 мл сироп</p>', '', 'baby-mix-5-pineapple-1567771447.jpg', 0, 0, 0, 1),
(61, 10, 0, 1567771494, 'BABY MIX (Orange flavoured)', 'BABY MIX 5 (Со вкусом апельсина)', '', '', '', '', '', '', '', '<p><strong>BABY MIX 5</strong>&nbsp;has a calming and polluting, antispasmodic effect thanks to its unique formula with natural active and effective ingredients. Baby Mix 5 also contains the active ingredient fennel, which has an antispasmodic effect on the smooth muscles of the intestines, which supports digestion, and is therefore widely used for spastic colic and digestive disorders.</p>\n\n<p><strong>Release form</strong>: 150 ml syrup</p>', '<p><strong>BABY MIX&nbsp;5</strong>&nbsp;благодаря уникальной формуле с натуральными активными и эффективными ингредиентами, обладает успокоивающим и ветрогонным, спазмолитическими действиями. Baby Mix 5 содержит активный компонент фенхель, который также способствует перевариванию, обладая спазмолитическим действием, особенно в отношении гладкой мускулатуры кишечника и поэтому широко применяется при спастических коликах и при расстройствах пищеварения.</p>\n\n<p><strong>Форма выпуска</strong>: 150 мл сироп</p>', '', 'baby-mix-5-orange-1567771673.jpg', 0, 0, 0, 1);



-- ---------------------------------------------------------
--
-- Table structure for table : `products2`
--
-- ---------------------------------------------------------

CREATE TABLE `products2` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` varchar(255) NOT NULL,
  `author_id` int(11) NOT NULL,
  `datetime` int(11) NOT NULL,
  `name_en` varchar(255) NOT NULL,
  `name_ru` varchar(255) NOT NULL,
  `name_az` varchar(255) NOT NULL,
  `keywords_en` varchar(255) NOT NULL,
  `keywords_ru` varchar(255) NOT NULL,
  `keywords_az` varchar(255) NOT NULL,
  `short_text_en` varchar(500) NOT NULL,
  `short_text_ru` varchar(500) NOT NULL,
  `short_text_az` text NOT NULL,
  `full_text_en` text NOT NULL,
  `full_text_ru` text NOT NULL,
  `full_text_az` text NOT NULL,
  `image` varchar(255) NOT NULL,
  `read_count` int(11) NOT NULL DEFAULT 0,
  `comment_count` int(11) NOT NULL DEFAULT 0,
  `flash` tinyint(1) NOT NULL,
  `active` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `kateqoriya` (`category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `products2`
--

INSERT INTO `products2` (`id`, `category_id`, `author_id`, `datetime`, `name_en`, `name_ru`, `name_az`, `keywords_en`, `keywords_ru`, `keywords_az`, `short_text_en`, `short_text_ru`, `short_text_az`, `full_text_en`, `full_text_ru`, `full_text_az`, `image`, `read_count`, `comment_count`, `flash`, `active`) VALUES
(1, 3, 0, 1562397196, '', '', '', '', '', '', '', '', '', '', '', '', 'product-grey-7-1562397243.jpg', 0, 0, 1, 0),
(2, 3, 0, 1562397375, '', '', '', '', '', '', '', '', '', '', '', '', 'product-grey-7-1562397375.jpg', 0, 0, 0, 0);



-- ---------------------------------------------------------
--
-- Table structure for table : `questions`
--
-- ---------------------------------------------------------

CREATE TABLE `questions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `question_en` varchar(255) DEFAULT NULL,
  `question_ru` varchar(255) DEFAULT NULL,
  `question_az` varchar(255) NOT NULL,
  `answer_en` varchar(255) DEFAULT NULL,
  `answer_ru` varchar(255) DEFAULT NULL,
  `answer_az` varchar(255) NOT NULL,
  `datetime` int(11) NOT NULL,
  `tip` tinyint(1) NOT NULL COMMENT '0=>one, 1=>many',
  `vote_count` int(11) NOT NULL,
  `active` tinyint(1) DEFAULT 0,
  `position` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `parent_id`, `question_en`, `question_ru`, `question_az`, `answer_en`, `answer_ru`, `answer_az`, `datetime`, `tip`, `vote_count`, `active`, `position`) VALUES
(8, 6, '', '', '', '', '', '', 1503552581, 0, 0, 1, 2),
(6, 0, '', '', 'iii', '', '', '', 1503552261, 1, 0, 1, 1),
(7, 6, '', '', '', '', '', '', 1503552559, 0, 0, 1, 1);



-- ---------------------------------------------------------
--
-- Table structure for table : `questions_ip`
--
-- ---------------------------------------------------------

CREATE TABLE `questions_ip` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(15) NOT NULL,
  `question_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



-- ---------------------------------------------------------
--
-- Table structure for table : `services`
--
-- ---------------------------------------------------------

CREATE TABLE `services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_en` varchar(100) NOT NULL,
  `name_ru` varchar(100) NOT NULL,
  `name_az` varchar(255) NOT NULL,
  `short_text_en` varchar(255) NOT NULL,
  `short_text_ru` varchar(255) NOT NULL,
  `short_text_az` text NOT NULL,
  `full_text_en` text NOT NULL,
  `full_text_ru` text NOT NULL,
  `full_text_az` text NOT NULL,
  `image` varchar(100) NOT NULL DEFAULT '0',
  `position` int(11) NOT NULL,
  `active` int(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `name_en`, `name_ru`, `name_az`, `short_text_en`, `short_text_ru`, `short_text_az`, `full_text_en`, `full_text_ru`, `full_text_az`, `image`, `position`, `active`) VALUES
(1, '', 'Гловные боли', 'Osteoxondrozun müalicəsi', '', 'Эффективное лечение хронических головных болей, мигреней, черепно-мозговых болей', 'Xəstəliyin remissiyası (sakitləşmə) dövrlərində xüsusi massaj və müalicəvi fiziki tərbiyyəsi, manual terapiya, fizioterapiya (elektroforez), onurğa sütunu uzatması (xüsusi klinikalarda həyata keçirilir), xüsusi müalicəvi vannalar, bəzi dərman preparatları tətbiq edilir.', '', '', '<p>Xəstəliyin remissiyası (sakitləşmə) dövrlərində xüsusi massaj və müalicəvi fiziki tərbiyyəsi, manual terapiya, fizioterapiya (elektroforez), onurğa sütunu uzatması (xüsusi klinikalarda həyata keçirilir), xüsusi müalicəvi vannalar, bəzi dərman preparatları tətbiq edilir.</p>', 'osteoxondrozxesteliyininmualicesi-1608138145.jpg', 1, 1),
(2, '', 'Боли в области лица', 'Boyun Fəqərəarası Disk Yırtığı', '', 'Лечение тригеминальной невралгии, невралгии лицевого нерва, болей в височной и глазной областях', 'Əməliyyatsız boyun yırtığı müalicəsi bərpa və reabilitasiya prosesindən sonra DRX 9000 tətbiqi, daha sonra ehtiyac olan zaman yüksək sıxlıqlı lazer və manual terapiya tətbiq olunaraq bir seanslıq müalicə başa çatmış olur. Müalicə bitdikdən sonra, xüsusi məşq proqramları ilə xəstənin boyun ətrafındakı əzələlər gücləndirilərək, boyun onurğalarına düşən yük azalır. Xüsusilə oturaq çalışan xəstələrin bu məşqlərə aravermədən davam etməsi müalicənin effektini artırır.', '', '', '<p>Əməliyyatsız boyun yırtığı müalicəsi bərpa və reabilitasiya prosesindən sonra DRX 9000 tətbiqi, daha sonra ehtiyac olan zaman yüksək sıxlıqlı lazer və manual terapiya tətbiq olunaraq bir seanslıq müalicə başa çatmış olur. Müalicə bitdikdən sonra, xüsusi məşq proqramları ilə xəstənin boyun ətrafındakı əzələlər gücləndirilərək, boyun onurğalarına düşən yük azalır. Xüsusilə oturaq çalışan xəstələrin bu məşqlərə aravermədən davam etməsi müalicənin effektini artırır.</p>', 'boyunfeqerelerarasiqrijayirtiq-1608138357.jpg', 2, 1),
(8, '', 'Боли, возникшие после заболевания', 'Onurğanın yaralanma sonrası müalicəsi', '', 'Лечение острых, ощутимых болей, вызванных инсультом, различными онкологическими заболеваниями', 'Onurğa beyni zədələrinin müalicəsi və bərpası mütəxəssis bölmələr tərəfindən aparılmalıdır.\n\nBir onurğa beyni zədəsinin çoxşaxəli izləri adətən qalıcıdır və müalicə etmək çətindir. Buna görə müalicə ekspertiza və fərdi planlaşdırma tələb edir.', '', '', '<p>Onurğa beyni zədələrinin müalicəsi və bərpası mütəxəssis bölmələr tərəfindən aparılmalıdır.</p>\n<p>Bir onurğa beyni zədəsinin çoxşaxəli izləri adətən qalıcıdır və müalicə etmək çətindir. Buna görə müalicə ekspertiza və fərdi planlaşdırma tələb edir.</p>', 'onurganin-yaralanma-sonrasi-muumlalicesi-1608150794.jpg', 6, 1),
(3, '', 'Боль в спине', 'Pleksit', '', 'Лечение остеохондроза, болей, вызванных грыжей поясничного отдела (разрывов диска)', 'Pleksit — Onurğa beyni sinirləri kələfinin xəstəliyidir. Pleksitin səbəbi travmalar, infeksion xəstəliklər, onurğa xəstəlikləri və s. ola bilər. Boyun pleksiti zamanı boyunun dərin əzələlərinin iflici, ənsə nahiyəsində ağrı olur. Xəstəlik kəskin davam edir. Bazu pleksiti zamanı çiyin və yuxarı ət­raf əzələləri birlikdə prosesə cəlb olunur, körpücükaltı və körpücüküstü nahiyələr ağrılı olur, ağrı yuxarı ətrafa da vurur və süst-atrofik iflic baş verir. Yuxarı ətrafların hərəkəti məhdudlaşır. Xəstəlik əksər hallarda 2-3 ay müddətində sağalma ilə nəticələnir, bəzən isə yuxarı ətrafın periferik iflici sabit qalır. Bel-oma pleksitinin klinik əlamətləri bel nahiyəsində olan ağrılardan iba­rətdir. Ağrılar bud və oturaq sinirlə­ri boyunca yayılıb, hissi pozğunluqlar verir. Ayaqda zəiflik olur. Müalicə xəstəliyin etiologiyasına əsaslanmalıdır. İnfeksiya ilə əlaqədar olduqda, iltihaba qarşı müa­licə aparılmalı, eyni zamanda ağrıkəsici dərmanlar, isti proseduralar və həkimin təyinatı üzrə digər müalicələr aparılmalıdır. Qadınlarda bel-oma pleksiti əlamətlə­ri olduqda onların ginekoloq tərəfin­dən müayinə olunması məsləhətdir.', '', '', '<p>Pleksit &mdash; Onurğa beyni sinirləri kələfinin xəstəliyidir. Pleksitin səbəbi travmalar, infeksion xəstəliklər, onurğa xəstəlikləri və s. ola bilər. Boyun pleksiti zamanı boyunun dərin əzələlərinin iflici, ənsə nahiyəsində ağrı olur. Xəstəlik kəskin davam edir. Bazu pleksiti zamanı çiyin və yuxarı ət&shy;raf əzələləri birlikdə prosesə cəlb olunur, körpücükaltı və körpücüküstü nahiyələr ağrılı olur, ağrı yuxarı ətrafa da vurur və süst-atrofik iflic baş verir. Yuxarı ətrafların hərəkəti məhdudlaşır. Xəstəlik əksər hallarda 2-3 ay müddətində sağalma ilə nəticələnir, bəzən isə yuxarı ətrafın periferik iflici sabit qalır. Bel-oma pleksitinin klinik əlamətləri bel nahiyəsində olan ağrılardan iba&shy;rətdir. Ağrılar bud və oturaq sinirlə&shy;ri boyunca yayılıb, hissi pozğunluqlar verir. Ayaqda zəiflik olur. Müalicə xəstəliyin etiologiyasına əsaslanmalıdır. İnfeksiya ilə əlaqədar olduqda, iltihaba qarşı müa&shy;licə aparılmalı, eyni zamanda ağrıkəsici dərmanlar, isti proseduralar və həkimin təyinatı üzrə digər müalicələr aparılmalıdır. Qadınlarda bel-oma pleksiti əlamətlə&shy;ri olduqda onların ginekoloq tərəfin&shy;dən müayinə olunması məsləhətdir.</p>', 'pleksit-1608140100.jpg', 3, 1),
(4, '', 'Боли в суставах', 'Miqren ağrıları', '', 'Устранение болей, вызванных артрозом (износ суставов), артритом, ревматизмом, аваскулярным некрозом и восстановление суставов', 'Miqrenin fiziki yollarla müalicəsində başlıca məqsəd miqren tutmalarının qan-damar və mərkəzi sinir sisteminin işini requlyasiya etmək, sinir sisteminin oyanıqlığını, həyəcanı, depressiya hallarını aradan qaldırmaq hesabına, adaptasiya prosesini təkmilləşdirməkdən ibarətdir.', '', '', '<p><span>Miqren tutmaları anında fizioterapevtik müalicə. Ağır miqren tutmaları zamanı (hemikraniya, güclü işığa və yüksək səsə qarşı həssaslıq, ürəkbulanma, pulsasiya hissi) xəstələri sakit və qaranlıq otağa yerləşdirmək lazımdır. Dərman preparatlarından serotoninin selektiv aqonistlərindən (imiqran, naramiq),analgetiklər, qusmaəleyhinə dərman preparatları və onların kombinasiyalar, erqotamin və s. təyin edilir. Medikamentoz terapiya ilə yanaşı vazospastik formada baş nahiyyəsinə isti su ilə doldurulmuş qrelka, ənsə nahiyyəsinə xardal aplikasiyaları, isti vannalar, baş və çiyin nahiyyəsinin müalicəvi massaji tətbiq edilməlidir. Vazodilatasiya zamanı baş nahiyyəsinə soyuq (buz və ya soyuq su qovuğu), ətraflara isə-əl və ayaq nahiyyələrinə isti vannalar (temperapuru 40-42 dərəcə) qoyulmalıdır. Bu zaman kişik və böyük damarların açılması səbəbindən qanın yenidən paylanması müşahidə edilir. Bu prosedur beyin qan dövranına müsbət təsir göstərir. Vannaların tətbiqi pasientlərdə yaxşı nəticə əldə etməyə, simptomatikanın qısa zaman ərzində azalmasına yardım edir. Prosedurun davam etmə müddəti 15 dəq olub, gündəlik olaraq 15 gün içində tətbiq edilməlidir.</span></p>', 'miqrenagrilari-1608150012.png', 4, 1),
(7, '', 'Мышечные боли', 'Kifoz, lordoz, skolioz', '', 'Устранение болей в руках, запястье, ногах и других мышцах тела, возникших из-за спортивных нагрузок или по другим причинам.', 'Skelet inkişafını tamamlamamış xəstələrdə artmaqda olan skolyoz və kifoz üçün korset (ortez) müalicəsi təklif olunur. Orta dərəcədə skolyoz və Schuermann kifozu üçün korset müalicəsi uyğun ola bilər. Bazarda bir çox növ korset vardır.', '', '', '<p><span>Skelet inkişafını tamamlamamış xəstələrdə artmaqda olan skolyoz və kifoz üçün korset (ortez) müalicəsi təklif olunur. Orta dərəcədə skolyoz və Schuermann kifozu üçün korset müalicəsi uyğun ola bilər. Bazarda bir çox növ korset vardır. Hamısı uşaq böyüyərkən əyriliyinin artmasını maneə törətmək üçün dizayn edilmişdir. Kors, aktiv skelet böyüməsi əsnasında əyriliyin artmasına maneə törətmək üçündür. Kors onurğanı tamamilə düzəldə, və xəstələrin təxmini olaraq ən azı yarısında əyriliyin artmasına mane ola bilməz. Korsetdən gözlənilən ən yaxşı müvəffəqiyyət əyriliyin təsbit edildiyi dərəcədə qalıb daha çox irəliləməməsi və cərrahi sərhədə gəlib cıxmamasıdır. Bir çox hallarda xəstələr idmanı müalicə növü kimi görür. lakin bu belə deyil. İdman yalnız və yalnız prafilaktik fizioterapevtik müalicədir. Yəni müalicədən sonra əyriliyin artmasının qarşısını alır. Ona görə də mütləq həkimə müraciət etmək lazımdır.</span></p>\n\n<div id="gtx-trans" style="position: absolute; left: 359px; top: 33px;">&nbsp;</div>', 'kifozskolioz-1608150390.jpg', 5, 1);



-- ---------------------------------------------------------
--
-- Table structure for table : `settings`
--
-- ---------------------------------------------------------

CREATE TABLE `settings` (
  `id` tinyint(4) NOT NULL AUTO_INCREMENT,
  `admin_name` varchar(255) NOT NULL,
  `title_` varchar(255) NOT NULL,
  `keywords_` varchar(255) NOT NULL,
  `description_` varchar(255) NOT NULL,
  `currency` tinyint(1) NOT NULL,
  `wheather` tinyint(1) NOT NULL,
  `namaz` tinyint(1) NOT NULL,
  `admin_with_role` tinyint(1) NOT NULL,
  `include_site_langs` tinyint(1) NOT NULL,
  `want_license_pass_change` tinyint(1) NOT NULL,
  `image_logo` varchar(255) NOT NULL,
  `image_fav` varchar(255) NOT NULL,
  `default_page` varchar(50) NOT NULL,
  `image_crop` tinyint(1) NOT NULL,
  `license_key` varchar(255) NOT NULL,
  `last_backup` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `admin_name`, `title_`, `keywords_`, `description_`, `currency`, `wheather`, `namaz`, `admin_with_role`, `include_site_langs`, `want_license_pass_change`, `image_logo`, `image_fav`, `default_page`, `image_crop`, `license_key`, `last_backup`) VALUES
(1, 'Admin Panel', 'Elite Admin', '', '', 0, 0, 0, 0, 0, 0, 'edik-1515503844.png', 'favicon-1515568701.png', 'menus', 0, '1e176f4648643465b4363c95561e0bba', 1612767165);



-- ---------------------------------------------------------
--
-- Table structure for table : `settings_inner`
--
-- ---------------------------------------------------------

CREATE TABLE `settings_inner` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `table_name` varchar(50) NOT NULL,
  `parent_id_available` tinyint(1) NOT NULL,
  `position_available` tinyint(1) NOT NULL,
  `position_desc` tinyint(1) NOT NULL COMMENT '0=>asc, 1=>desc',
  `position_depends_parent_id` tinyint(1) NOT NULL,
  `multiselect_available` tinyint(1) NOT NULL,
  `active_available` tinyint(1) NOT NULL,
  `edit_available` tinyint(1) NOT NULL,
  `delete_available` tinyint(1) NOT NULL,
  `show_per_page_available` tinyint(1) NOT NULL,
  `print_available` tinyint(1) NOT NULL,
  `add_new_available` tinyint(1) NOT NULL,
  `paginator_available` tinyint(1) NOT NULL,
  `category_available` tinyint(1) NOT NULL,
  `upload_important` tinyint(1) NOT NULL,
  `show_datacount` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=170 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `settings_inner`
--

INSERT INTO `settings_inner` (`id`, `table_name`, `parent_id_available`, `position_available`, `position_desc`, `position_depends_parent_id`, `multiselect_available`, `active_available`, `edit_available`, `delete_available`, `show_per_page_available`, `print_available`, `add_new_available`, `paginator_available`, `category_available`, `upload_important`, `show_datacount`) VALUES
(81, 'employees', 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(73, 'videogallery', 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(74, 'users', 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(152, 'cash_desks', 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(76, 'admins', 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(77, 'contacts', 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0),
(78, 'sliders', 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(79, 'banners', 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(80, 'partners', 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(137, 'banks', 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(63, 'home_page', 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0),
(64, 'description', 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0),
(65, 'subscribers', 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(66, 'menus', 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(67, 'categories', 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(68, 'news', 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(69, 'faq_categories', 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(70, 'faq', 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(71, 'about', 0, 0, 0, 0, 1, 0, 1, 1, 0, 1, 0, 0, 0, 0, 0),
(72, 'photo_albums', 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(82, 'services', 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(83, 'links', 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(84, 'authors', 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(85, 'fb_admins', 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(92, 'documents', 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(87, 'letters', 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(88, 'comments', 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(89, 'questions', 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(90, 'langs', 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(153, 'our_cash_desks', 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(139, 'admin_roles', 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(138, 'settings_inner', 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(140, 'settings', 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(147, 'image_cropper', 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0),
(148, 'photo_albums_gallery', 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(151, 'index', 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(154, 'payments', 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(155, 'money_balance', 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(156, 'user_programs', 1, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(157, 'workers', 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(158, 'news_gallery', 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(159, 'countries', 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(160, 'products', 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1),
(161, 'categories2', 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(162, 'products2', 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1),
(163, 'patients', 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(164, 'methods', 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(165, 'users_contact', 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 1),
(166, 'appointment', 0, 0, 0, 0, 1, 0, 1, 1, 1, 1, 0, 1, 0, 0, 1),
(169, 'appointment_users', 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 1);



-- ---------------------------------------------------------
--
-- Table structure for table : `sliders`
--
-- ---------------------------------------------------------

CREATE TABLE `sliders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_en` varchar(255) NOT NULL,
  `name_ru` varchar(255) NOT NULL,
  `name_az` varchar(255) NOT NULL,
  `title_en` varchar(250) NOT NULL,
  `title_ru` varchar(250) NOT NULL,
  `title_az` varchar(250) NOT NULL,
  `text_en` text NOT NULL,
  `text_ru` text NOT NULL,
  `text_az` text NOT NULL,
  `image` varchar(255) NOT NULL DEFAULT '0',
  `url` varchar(255) NOT NULL,
  `target` varchar(255) NOT NULL,
  `position` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sliders`
--

INSERT INTO `sliders` (`id`, `name_en`, `name_ru`, `name_az`, `title_en`, `title_ru`, `title_az`, `text_en`, `text_ru`, `text_az`, `image`, `url`, `target`, `position`, `active`) VALUES
(1, 'Slider 1_en', 'Мы лечим вашу боль', 'FİZİOTERAPEVT', 'Slider 1_en title', 'Вусал Эйвазов', 'Dr. Ramazan Nasırlı', 'Slider 1_en text', '', '', 'ramazannasirli-1608048399.png', '', '', 1, 1),
(7, '', '', 'Fizioterapevt Dr. Ramazan Nasırlı', '', '', '', '', '', '', 'fizioterapevtramazannesirli-1610794864.jpg', '', '', 2, 0);



-- ---------------------------------------------------------
--
-- Table structure for table : `subscribers`
--
-- ---------------------------------------------------------

CREATE TABLE `subscribers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;



-- ---------------------------------------------------------
--
-- Table structure for table : `user_programs`
--
-- ---------------------------------------------------------

CREATE TABLE `user_programs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `login` varchar(50) NOT NULL,
  `pass` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `role_id` int(11) NOT NULL,
  `permissions` text NOT NULL,
  `settings` varchar(500) NOT NULL,
  `full_list_access` varchar(500) NOT NULL,
  `price` int(11) NOT NULL,
  `expire_time` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



-- ---------------------------------------------------------
--
-- Table structure for table : `users`
--
-- ---------------------------------------------------------

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `login` varchar(50) NOT NULL,
  `pass` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `about` varchar(255) NOT NULL,
  `gender` tinyint(1) NOT NULL COMMENT '0=>female, 1=>male',
  `mobile` varchar(50) NOT NULL,
  `create_date` int(11) NOT NULL,
  `birthday` int(11) NOT NULL,
  `last_visit` int(11) NOT NULL,
  `ip` varchar(15) NOT NULL,
  `image` varchar(255) NOT NULL,
  `activation` tinyint(1) NOT NULL COMMENT 'for email activation',
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `login`, `pass`, `email`, `about`, `gender`, `mobile`, `create_date`, `birthday`, `last_visit`, `ip`, `image`, `activation`, `active`) VALUES
(2, 'Elnur Alizade', 'Develop', '14e1b600b1fd579f47433b88e8d85291', 'elnur-sun17@mail.ru', 'test', 1, '050 443 00 50', 1357331929, -14400, 0, '', '', 1, 1);



-- ---------------------------------------------------------
--
-- Table structure for table : `videogallery`
--
-- ---------------------------------------------------------

CREATE TABLE `videogallery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_en` varchar(255) NOT NULL,
  `name_ru` varchar(255) NOT NULL,
  `name_az` varchar(255) NOT NULL,
  `video_url` varchar(255) NOT NULL,
  `position` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `videogallery`
--

INSERT INTO `videogallery` (`id`, `name_en`, `name_ru`, `name_az`, `video_url`, `position`, `active`) VALUES
(32, '', '', 'Fizioterapevt Dr. Ramazan Nasırlı', 'https://www.youtube.com/watch?v=TCwH3rYiWPk', 1, 1),
(33, '', '', 'Fizioterapevt Dr. Ramazan Nasırlı', 'https://www.youtube.com/watch?v=iVGOV6vvs4A', 2, 1),
(34, '', '', 'Türkiyədən Azərbaycana dəvət almış #Fizioterapevt Ramazan Nəsirli kimdir?', 'https://www.youtube.com/watch?v=QKFdcSQCpGk&feature=emb_title&ab_channel=Dr.RamazanNas%C4%B1rl%C4%B1', 3, 1);



-- ---------------------------------------------------------
--
-- Table structure for table : `wheather`
--
-- ---------------------------------------------------------

CREATE TABLE `wheather` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `baki` varchar(255) NOT NULL,
  `naxcivan` varchar(255) NOT NULL,
  `sumqayit` varchar(255) NOT NULL,
  `gence` varchar(255) NOT NULL,
  `lenkeran` varchar(255) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `wheather`
--

INSERT INTO `wheather` (`id`, `baki`, `naxcivan`, `sumqayit`, `gence`, `lenkeran`, `date`) VALUES
(1, '28```18', '0-0', '0-0', '', '', '2015-09-01');


/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;